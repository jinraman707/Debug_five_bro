# -Debug five bro-
졸업과제를 열심히 해보자!

## 차친구

주변 차량과 짧은 메시지를 주고받는 졸업작품 시험판입니다. Android 앱과 Python 서버를 함께 실행합니다.

- [설치와 실행 방법](chachingu/README.md)
- [Android 1.4 시험용 APK](chachingu/apk/chachingu-1.4.apk?raw=true)
- [두 단말 실기기 시험표](chachingu/DEVICE-TEST.md)
