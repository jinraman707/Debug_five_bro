package kr.ac.capstone.chachingu;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public final class FlowCheck {
    public static void main(String[] args) {
        float[][] vectors = {{0,-1}, {1,-1}, {1,0}, {1,1}, {0,1}, {-1,1}, {-1,0}, {-1,-1}};
        for (int i = 0; i < vectors.length; i++) {
            check(QuickMessage.inDirection(vectors[i][0], vectors[i][1]).ordinal() == i, "방향 " + i);
        }
        PendingMessage draft = new PendingMessage("감사합니다.", "B", 1000);
        check(draft.remaining(1000) == 2000, "첫 카운트다운");
        check("B".equals(draft.recipient), "대상 고정");
        check(!draft.cancelOnTap(1400, 300), "한 번 탭 유지");
        check(draft.cancelOnTap(1699, 300), "두 번 탭 취소");
        draft.resetTaps();
        check(!draft.cancelOnTap(2000, 300), "새 첫 탭");
        check(!draft.cancelOnTap(2350, 300), "탭 간격 확인");
        check(!draft.cancelOnTap(3000, 300), "만료 후 취소 방지");
        check(draft.remaining(3000) == 0, "2초 경계");
        check(VoiceInput.isWakePhrase("안녕, 차친구야!"), "표준 호출어");
        check(!VoiceInput.isWakePhrase("안녕 차친구야 안녕"), "호출어 오인식 방지");
        check(VoiceInput.plateDigits("오 육 칠 팔").equals("5678"), "한국어 번호");
        check(VoiceInput.plateDigits("공-1-이-3").equals("0123"), "혼합 번호");
        check(VoiceInput.plateDigits("차 5678").isEmpty(), "번호 외 말 거부");
        check(VoiceInput.pronouncePlate("78라 5678").replace(" ", "").equals("칠팔라오육칠팔"),
                "차량번호 낭독");
        checkVoiceTarget();
        DeliveryTracker deliveries = new DeliveryTracker();
        deliveries.begin("first");
        deliveries.expect("first", 1000, false);
        check(deliveries.observe("unknown", "delivered") == DeliveryTracker.Update.NONE, "다른 발신은 무시");
        check(deliveries.observe("first", "accepted") == DeliveryTracker.Update.ACCEPTED, "응답 유실 뒤 기록으로 접수 확인");
        check(deliveries.observe("first", "accepted") == DeliveryTracker.Update.NONE, "접수 반복 표시 방지");
        deliveries.begin("second");
        deliveries.expect("second", 2000, true);
        check(!deliveries.isLatest("first") && deliveries.isLatest("second"), "늦은 기록은 새 발신 상태를 덮지 않음");
        check(deliveries.observe("first", "delivered") == DeliveryTracker.Update.DELIVERED, "수신 확인");
        check(deliveries.observe("first", "delivered") == DeliveryTracker.Update.NONE, "완료 알림은 한 번");
        check(deliveries.observe("second", "accepted") == DeliveryTracker.Update.NONE, "정상 접수는 다시 표시하지 않음");
        check(deliveries.observe("second", "expired") == DeliveryTracker.Update.EXPIRED, "전달 만료 확인");
        deliveries.begin("third");
        deliveries.expect("third", 3000, false);
        check(!deliveries.expire(22999) && deliveries.hasPending(), "제한 전까지 조회 유지");
        check(deliveries.expire(23000) && !deliveries.hasPending(), "접수 미확인 조회 종료");
        deliveries.begin("fourth");
        deliveries.expect("fourth", 24000, true);
        check(!deliveries.expire(44000) && !deliveries.hasPending(), "접수 확인 건은 미확인으로 표시하지 않음");
        deliveries.expect("fourth", 24000, false);
        deliveries.clear();
        check(!deliveries.hasPending() && !deliveries.isLatest("fourth"), "연결 종료 시 추적 해제");
        System.out.println("42 Java assertions passed.");
    }

    private static void checkVoiceTarget() {
        Map<String, String> plates = new LinkedHashMap<>();
        plates.put("B", "78라 5678");
        plates.put("C", "90마 9012");
        VoiceInput.PlateMatch normal = VoiceInput.matchPlate(Collections.singletonList("오 육 칠 팔"), plates);
        check(normal.status == VoiceInput.PlateStatus.MATCH && "B".equals(normal.recipient)
                && "5678".equals(normal.digits), "인식 결과 하나로 정상 차량 선택");
        VoiceInput.PlateMatch similar = VoiceInput.matchPlate(Arrays.asList("5678", "오 육 칠 팔", "0000"), plates);
        check(similar.status == VoiceInput.PlateStatus.MATCH && "B".equals(similar.recipient),
                "같은 번호 표현과 주변에 없는 후보 제외");
        VoiceInput.PlateMatch ambiguous = VoiceInput.matchPlate(Arrays.asList("5678", "오 육 칠 팔", "9012"), plates);
        check(ambiguous.status == VoiceInput.PlateStatus.AMBIGUOUS_SPEECH && ambiguous.recipient == null,
                "세 번째 인식 후보도 가까운 다른 차량이면 선택 보류");
        VoiceInput.PlateMatch fallback = VoiceInput.matchPlate(Arrays.asList("0000", "5678"), plates);
        check(fallback.status == VoiceInput.PlateStatus.NOT_NEARBY && fallback.recipient == null,
                "주변에 없는 첫 번호를 차순위 번호로 바꾸지 않음");
        check(VoiceInput.matchPlate(Arrays.asList("차 5678", "5678"), plates).status
                == VoiceInput.PlateStatus.INVALID_NUMBER, "번호 이외의 첫 인식 결과 거부");
        check(VoiceInput.matchPlate(Arrays.asList(null, "5678"), plates).status
                == VoiceInput.PlateStatus.INVALID_NUMBER, "비어 있는 첫 인식 결과 거부");
        plates.put("D", "55나 5678");
        VoiceInput.PlateMatch duplicate = VoiceInput.matchPlate(Collections.singletonList("5678"), plates);
        check(duplicate.status == VoiceInput.PlateStatus.DUPLICATE_SUFFIX && duplicate.recipient == null,
                "차량 두 대의 뒤 번호가 같으면 전송 보류");
        plates.remove("B");
        check("D".equals(VoiceInput.matchPlate(Collections.singletonList("5678"), plates).recipient),
                "확인 뒤 차량이 바뀌면 차량 ID 비교로 구별");
    }

    private static void check(boolean ok, String name) {
        if (!ok) throw new AssertionError(name);
    }
}
