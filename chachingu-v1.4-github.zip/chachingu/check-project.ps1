param(
    [string]$Python = 'python',
    [string]$SdkPath = $(if ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { "$env:USERPROFILE\AppData\Local\Android\Sdk" }),
    [string]$JdkPath = "$env:ProgramFiles\Android\Android Studio\jbr",
    [string]$OutputPath = "$PSScriptRoot\build\chachingu.apk"
)
$ErrorActionPreference = 'Stop'
$OutputPath = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputPath)
Push-Location "$PSScriptRoot\server"
try {
    & $Python -m unittest -v
    if ($LASTEXITCODE -ne 0) { throw '서버 테스트 실패' }
} finally {
    Pop-Location
}

$out = Join-Path $PSScriptRoot "build\logic-check"
New-Item -ItemType Directory -Force -Path $out | Out-Null
$java = Join-Path $JdkPath 'bin'
$src = "$PSScriptRoot\app\src\main\java\kr\ac\capstone\chachingu"
$sources = @("$src\VoiceInput.java", "$src\QuickMessage.java", "$src\PendingMessage.java",
    "$src\DeliveryTracker.java", "$PSScriptRoot\checks\FlowCheck.java")
& "$java\javac.exe" -encoding UTF-8 -d $out @sources
if ($LASTEXITCODE -ne 0) { throw 'Java 테스트 컴파일 실패' }
& "$java\java.exe" -cp $out kr.ac.capstone.chachingu.FlowCheck
if ($LASTEXITCODE -ne 0) { throw 'Java 동작 확인 실패' }
& "$PSScriptRoot\build-apk.ps1" -SdkPath $SdkPath -JdkPath $JdkPath -OutputPath $OutputPath
