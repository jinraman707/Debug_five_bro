package kr.ac.capstone.chachingu;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

final class RadialMenuView extends View {
    private static final int MINT = 0xFF9CF5D3;
    private static final int DARK_INK = 0xFF10241E;
    private static final int RING = 0xFF28413F;
    private static final int SURFACE = 0xFF182832;
    private static final int WHITE = 0xFFF1F7F7;
    private static final Typeface BOLD = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    private static final float DIAGONAL = 0.70710677f;
    private static final float[] X = {0, DIAGONAL, 1, DIAGONAL, 0, -DIAGONAL, -1, -DIAGONAL};
    private static final float[] Y = {-1, -DIAGONAL, 0, DIAGONAL, 1, DIAGONAL, 0, -DIAGONAL};

    interface Listener {
        void onGesture(boolean opened, QuickMessage highlighted);
        void onChoose(QuickMessage message);
        void onAccessibleChoose();
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tile = new RectF();
    private final Listener listener;
    private final float density;
    private final float touchSlop;
    private boolean pressed;
    private boolean opened;
    private boolean pending;
    private float downX;
    private float downY;
    private QuickMessage selected;
    private String[] labels;
    private final Runnable open = this::openMenu;

    RadialMenuView(Context context, Listener listener) {
        super(context);
        this.listener = listener;
        density = getResources().getDisplayMetrics().density;
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        setClickable(true);
        setFocusable(true);
        setContentDescription("퀵 메시지. 중앙에서 길게 누르고 원하는 방향으로 드래그");
    }

    private float dp(float value) {
        return value * density;
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int width = MeasureSpec.getSize(widthSpec);
        int desired = Math.min(width, Math.round(dp(322)));
        setMeasuredDimension(width, resolveSize(desired, heightSpec));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float outerRadius = Math.min(cx, cy) - dp(10);
        if (outerRadius <= 0) return;
        float orbit = outerRadius * .76f;

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(RING);
        canvas.drawCircle(cx, cy, outerRadius, paint);
        canvas.drawCircle(cx, cy, outerRadius * .60f, paint);
        paint.setStyle(Paint.Style.FILL);
        for (int i = 0; i < QuickMessage.CLOCKWISE.length; i++) {
            if (opened) {
                drawTile(canvas, i, cx + X[i] * orbit, cy + Y[i] * orbit);
            } else {
                paint.setColor(i % 2 == 0 ? 0xFF568779 : RING);
                canvas.drawCircle(cx + X[i] * orbit, cy + Y[i] * orbit, dp(i % 2 == 0 ? 3 : 2), paint);
            }
        }

        float centerRadius = centerRadius();
        paint.setColor(pressed ? 0xFF426F62 : 0xFF244940);
        canvas.drawCircle(cx, cy, centerRadius + dp(7), paint);
        paint.setColor(pending ? 0xFFB7D0C9 : MINT);
        canvas.drawCircle(cx, cy, centerRadius, paint);
        paint.setColor(DARK_INK);
        paint.setStrokeWidth(dp(2));
        paint.setStrokeCap(Paint.Cap.ROUND);
        float iconY = cy - dp(20);
        canvas.drawLine(cx - dp(11), iconY, cx + dp(11), iconY, paint);
        canvas.drawLine(cx, iconY - dp(11), cx, iconY + dp(11), paint);
        canvas.drawCircle(cx, iconY, dp(3.5f), paint);
        drawText(canvas, pending ? "전송 대기" : opened ? "드래그" : "퀵 메시지",
                cx, cy + dp(4), 16, DARK_INK, BOLD);
        drawText(canvas, pending ? "두 번 탭해 취소" : opened ? "방향에서 손 떼기" : "길게 누르기",
                cx, cy + dp(23), 11, DARK_INK, Typeface.DEFAULT);
    }

    private void drawTile(Canvas canvas, int i, float x, float y) {
        QuickMessage message = QuickMessage.CLOCKWISE[i];
        boolean active = message == selected;
        tile.set(x - dp(34), y - dp(25), x + dp(34), y + dp(25));
        paint.setColor(active ? MINT : SURFACE);
        canvas.drawRoundRect(tile, dp(13), dp(13), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(active ? MINT : RING);
        canvas.drawRoundRect(tile, dp(13), dp(13), paint);
        paint.setStyle(Paint.Style.FILL);

        int arrowColor = active ? DARK_INK : MINT;
        paint.setColor(arrowColor);
        paint.setStrokeWidth(dp(1.6f));
        canvas.save();
        canvas.translate(x, y - dp(8));
        canvas.rotate(i * 45f);
        canvas.drawLine(0, dp(5), 0, -dp(5), paint);
        canvas.drawLine(-dp(4), -dp(1), 0, -dp(5), paint);
        canvas.drawLine(dp(4), -dp(1), 0, -dp(5), paint);
        canvas.restore();
        drawText(canvas, labels == null ? message.label : labels[i], x, y + dp(11), 11,
                active ? DARK_INK : WHITE, BOLD);
    }

    private void drawText(Canvas canvas, String text, float x, float y, int size,
                          int color, Typeface typeface) {
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(typeface);
        paint.setTextSize(dp(size));
        paint.setColor(color);
        canvas.drawText(text, x, y - (paint.ascent() + paint.descent()) / 2f, paint);
    }

    private float centerRadius() {
        return dp(52);
    }

    private void openMenu() {
        if (!pressed) return;
        opened = true;
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        listener.onGesture(true, null);
        invalidate();
    }

    private void updateSelection(float x, float y) {
        float dx = x - getWidth() / 2f;
        float dy = y - getHeight() / 2f;
        float radius = (float) Math.hypot(dx, dy);
        QuickMessage next = radius > centerRadius() + dp(9)
                && x >= 0 && y >= 0 && x <= getWidth() && y <= getHeight()
                ? QuickMessage.inDirection(dx, dy) : null;
        if (selected == next) return;
        selected = next;
        if (next != null && Build.VERSION.SDK_INT >= 27) {
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        }
        listener.onGesture(true, next);
        invalidate();
    }

    void setPending(boolean pending) {
        this.pending = pending;
        setContentDescription(pending ? "전송 대기 중. 두 번 탭해 취소"
                : "퀵 메시지. 중앙에서 길게 누르고 원하는 방향으로 드래그");
        invalidate();
    }

    void setLabels(String[] labels) {
        this.labels = labels;
        invalidate();
    }

    void resetTouch() {
        removeCallbacks(open);
        boolean wasOpened = opened;
        pressed = false;
        opened = false;
        selected = null;
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
        if (wasOpened) listener.onGesture(false, null);
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (pending) return true;
        float x = event.getX();
        float y = event.getY();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (Math.hypot(x - getWidth() / 2f, y - getHeight() / 2f) > centerRadius()) {
                    return false;
                }
                downX = x;
                downY = y;
                pressed = true;
                getParent().requestDisallowInterceptTouchEvent(true);
                postDelayed(open, 350);
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (opened) {
                    updateSelection(x, y);
                } else if (pressed && Math.hypot(x - downX, y - downY) > touchSlop * 2) {
                    resetTouch();
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (opened) updateSelection(x, y);
                QuickMessage chosen = selected;
                resetTouch();
                if (chosen != null) listener.onChoose(chosen);
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
            case MotionEvent.ACTION_CANCEL:
                resetTouch();
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        if (!pending) listener.onAccessibleChoose();
        return true;
    }
}
