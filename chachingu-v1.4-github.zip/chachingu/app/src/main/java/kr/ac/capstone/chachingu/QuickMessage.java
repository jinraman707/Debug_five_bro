package kr.ac.capstone.chachingu;

enum QuickMessage {
    ROAD("전방 위험", "전방 도로에 위험이 있어요."),
    TRUNK("트렁크", "트렁크가 열렸어요."),
    SIGNAL("방향지시등", "방향지시등을 사용해주세요."),
    TIRES("타이어", "타이어 상태를 확인해주세요."),
    THANKS("감사", "감사합니다."),
    SORRY("사과", "죄송합니다."),
    DISTANCE("차간 거리", "차간 거리에 주의해주세요."),
    LIGHTS("전조등", "전조등을 확인해주세요.");

    static final QuickMessage[] CLOCKWISE = values();

    final String label;
    final String text;

    QuickMessage(String label, String text) {
        this.label = label;
        this.text = text;
    }

    static QuickMessage inDirection(float dx, float dy) {
        double angle = Math.atan2(dx, -dy);
        int sector = (int) Math.floor((angle + Math.PI / 8) / (Math.PI / 4));
        return CLOCKWISE[Math.floorMod(sector, CLOCKWISE.length)];
    }
}
