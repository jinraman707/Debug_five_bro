package kr.ac.capstone.chachingu;

final class PendingMessage {
    static final long DELAY_MS = 2_000;

    final String text;
    final String recipient;
    private final long deadline;
    private long firstTap = -1;

    PendingMessage(String text, String recipient, long startedAt) {
        this.text = text;
        this.recipient = recipient;
        deadline = startedAt + DELAY_MS;
    }

    long remaining(long now) {
        return Math.max(0, deadline - now);
    }

    void resetTaps() {
        firstTap = -1;
    }

    boolean cancelOnTap(long now, long doubleTapTimeoutMs) {
        if (remaining(now) == 0) return false;
        if (firstTap >= 0 && now - firstTap <= doubleTapTimeoutMs) return true;
        firstTap = now;
        return false;
    }
}
