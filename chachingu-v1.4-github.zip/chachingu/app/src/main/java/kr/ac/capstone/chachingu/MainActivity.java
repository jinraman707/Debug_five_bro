package kr.ac.capstone.chachingu;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.security.GeneralSecurityException;

public final class MainActivity extends Activity implements RadialMenuView.Listener {
    private static final int BACKGROUND = 0xFF0B141C;
    private static final int PANEL = 0xFF111F29;
    private static final int PANEL_DARK = 0xFF0E1A23;
    private static final int LINE = 0xFF28414B;
    private static final int WHITE = 0xFFF1F7F7;
    private static final int MUTED = 0xFFAAC0C6;
    private static final int MINT = 0xFF9CF5D3;
    private static final int AMBER = 0xFFFFD69A;
    private static final String GUIDE = "중앙을 길게 누른 뒤 원하는 방향으로 밀어주세요.";
    private static final String[] VEHICLES = {"시험 차량 A · 1234", "시험 차량 B · 5678", "시험 차량 C · 9012"};
    private static final int LOCATION_PERMISSION = 11;
    private static final int MIC_PERMISSION = 12;
    private static final int TRIP_NOTIFICATION_PERMISSION = 13;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable tick = this::updateCountdown;
    private final Runnable heartbeat = this::pollPresence;
    private final LinkedHashMap<String, JSONObject> peers = new LinkedHashMap<>();
    private final DeliveryTracker deliveries = new DeliveryTracker();
    private final String[] presets = new String[8];
    private SharedPreferences settings;
    private RideApi api;
    private DeviceEnrollment enrollment;
    private DeviceServices devices;
    private Inbox inbox;
    private RadialMenuView radial;
    private TextView connectivity;
    private TextView received;
    private TextView voiceButton;
    private TextView targetNumber;
    private TextView targetInfo;
    private TextView statusTitle;
    private TextView statusDetail;
    private TextView time;
    private ProgressBar progress;
    private String target = "";
    private String ownPlate = "";
    private String lastServiceMessage = "";
    private int voiceGeneration;
    private boolean active;
    private boolean locating;
    private boolean locationRequired;
    private boolean locationReady;
    private boolean polling;
    private boolean historyPolling;
    private boolean connecting;
    private boolean sending;
    private boolean voiceActive;
    private boolean requestedTrip;
    private long lastHistoryCheck;
    private long lastVoiceEnd;
    private PendingMessage pending;
    private boolean trackingTap;
    private float tapX;
    private float tapY;
    private long tapDownAt;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        settings = getSharedPreferences("chachingu", MODE_PRIVATE);
        api = new RideApi(main);
        enrollment = new DeviceEnrollment(this);
        devices = new DeviceServices(this, main, (id, stateName) -> inbox.playback(id, stateName));
        inbox = new Inbox(api, devices, () -> active && !TripService.running(),
                () -> !voiceActive && !sending && pending == null, this::showReceived, this::disconnectLocal);
        String restoredPlate = TripService.restore(api);
        if (restoredPlate != null) {
            ownPlate = restoredPlate;
            locationRequired = TripService.usesGps();
        }
        for (QuickMessage message : QuickMessage.CLOCKWISE) {
            presets[message.ordinal()] = settings.getString("preset_" + message.ordinal(), message.text);
        }
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildScreen();
        if (api.connected()) {
            connectivity.setText(ownPlate);
            showStatus("백그라운드 수신 중", GUIDE, MINT);
        }
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setBackgroundColor(BACKGROUND);

        LinearLayout root = column();
        root.setPadding(dp(20), dp(20), dp(20), dp(20));
        scroll.addView(root);
        setContentView(scroll);

        LinearLayout top = row();
        LinearLayout names = column();
        TextView product = text("차친구", 32, WHITE, true);
        names.addView(product);
        TextView subtitle = text("주변 차량 메시지", 14, MUTED, false);
        addWithTop(names, subtitle, 3);
        top.addView(names, new LinearLayout.LayoutParams(0, -2, 1f));
        connectivity = text("서버 연결", 12, MINT, true);
        connectivity.setPadding(dp(12), dp(13), dp(12), dp(13));
        connectivity.setBackground(shape(0xFF18352F, 50, 0));
        connectivity.setFocusable(true);
        connectivity.setOnClickListener(view -> connectionDialog());
        top.addView(connectivity);
        root.addView(top, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout recipient = row();
        recipient.setPadding(dp(14), dp(13), dp(14), dp(13));
        recipient.setBackground(new RippleDrawable(
                ColorStateList.valueOf(0x269CF5D3), shape(PANEL, 18, LINE), null));
        recipient.setFocusable(true);
        recipient.setOnClickListener(view -> chooseTarget());
        TextView marker = text("◎", 23, MINT, true);
        marker.setGravity(Gravity.CENTER);
        marker.setBackground(shape(0xFF1C3938, 13, 0));
        recipient.addView(marker, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout recipientNames = column();
        recipientNames.addView(text("받는 차량", 12, MUTED, false));
        targetNumber = text("", 21, WHITE, true);
        addWithTop(recipientNames, targetNumber, 1);
        targetInfo = text("", 12, MUTED, false);
        addWithTop(recipientNames, targetInfo, 2);
        LinearLayout.LayoutParams targetLayout = new LinearLayout.LayoutParams(0, -2, 1);
        targetLayout.leftMargin = dp(12);
        recipient.addView(recipientNames, targetLayout);
        TextView change = text("변경 ›", 14, MINT, true);
        recipient.addView(change);
        renderTarget();
        addWithTop(root, recipient, 22);

        LinearLayout controls = column();
        controls.setPadding(dp(5), 0, dp(5), 0);
        controls.setBackground(shape(PANEL_DARK, 23, LINE));
        radial = new RadialMenuView(this, this);
        renderPresets();
        controls.addView(radial, new LinearLayout.LayoutParams(-1, -2));
        addWithTop(root, controls, 13);

        LinearLayout feedback = column();
        feedback.setPadding(dp(15), dp(13), dp(15), dp(13));
        feedback.setBackground(shape(PANEL, 18, LINE));
        LinearLayout feedbackHeading = row();
        statusTitle = text("", 16, WHITE, true);
        statusTitle.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        feedbackHeading.addView(statusTitle, new LinearLayout.LayoutParams(0, -2, 1));
        time = text("", 17, MINT, true);
        time.setVisibility(View.GONE);
        feedbackHeading.addView(time);
        feedback.addView(feedbackHeading);
        statusDetail = text("", 13, MUTED, false);
        statusDetail.setLineSpacing(dp(4), 1);
        addWithTop(feedback, statusDetail, 4);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(MINT));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(LINE));
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressLayout = new LinearLayout.LayoutParams(-1, dp(5));
        progressLayout.topMargin = dp(10);
        feedback.addView(progress, progressLayout);
        addWithTop(root, feedback, 13);
        showStatus("연결 필요", "오른쪽 위에서 시험 서버에 연결해주세요.", WHITE);
        voiceButton = action("음성 보내기", this::startVoice);
        addWithTop(root, voiceButton, 12);
        received = text("", 14, MINT, true);
        received.setPadding(dp(12), dp(10), dp(12), dp(10));
        received.setBackground(shape(PANEL, 12, LINE));
        received.setVisibility(View.GONE);
        received.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        addWithTop(root, received, 10);
        LinearLayout tools = row();
        tools.addView(action("송수신 기록", this::showHistory), new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams settingsLayout = new LinearLayout.LayoutParams(0, -2, 1f);
        settingsLayout.leftMargin = dp(8);
        tools.addView(action("메시지 설정", this::settingsDialog), settingsLayout);
        addWithTop(root, tools, 10);
    }

    private TextView action(String label, Runnable click) {
        TextView view = text(label, 14, MINT, true);
        view.setGravity(Gravity.CENTER);
        view.setMinHeight(dp(48));
        view.setFocusable(true);
        view.setBackground(new RippleDrawable(ColorStateList.valueOf(0x269CF5D3),
                shape(PANEL, 14, LINE), null));
        view.setOnClickListener(v -> click.run());
        return view;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private LinearLayout row() {
        LinearLayout layout = new LinearLayout(this);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private TextView text(String value, float size, int color, boolean medium) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setIncludeFontPadding(false);
        if (medium) view.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return view;
    }

    private GradientDrawable shape(int fill, int radius, int outline) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radius));
        if (outline != 0) drawable.setStroke(dp(1), outline);
        return drawable;
    }

    private void addWithTop(LinearLayout column, View view, int top) {
        LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(-1, -2);
        layout.topMargin = dp(top);
        column.addView(view, layout);
    }

    private void showStatus(String title, String detail, int color) {
        statusTitle.setText(title);
        statusTitle.setTextColor(color);
        statusDetail.setText(detail);
    }

    private void renderTarget() {
        JSONObject peer = peers.get(target);
        targetNumber.setText(peer == null ? "차량 선택" : peer.optString("plate"));
        if (peer == null) {
            String info = !api.connected() ? "시험 서버 연결 후 선택" : locationRequired && !locationReady
                    ? "정확한 GPS 위치를 확인하는 중" : peers.size() + "대 연결 가능";
            targetInfo.setText(info);
        } else {
            targetInfo.setText(peerTitle(peer));
        }
    }

    private void chooseTarget() {
        if (busy()) return;
        if (!api.connected()) {
            connectionDialog();
            return;
        }
        if (locationRequired && !locating && !hasFineLocation()) {
            requestLocation();
            return;
        }
        if (peers.isEmpty()) {
            showStatus("연결 가능한 차량 없음", locationRequired && !locationReady
                    ? "정확한 위치 권한을 허용하고 GPS 위치를 기다려주세요."
                    : "다른 단말도 같은 서버에서 차량을 연결해주세요.", AMBER);
            return;
        }
        ArrayList<JSONObject> options = new ArrayList<>(peers.values());
        String[] choices = new String[options.size()];
        for (int i = 0; i < choices.length; i++) {
            JSONObject peer = options.get(i);
            choices[i] = peer.optString("plate") + " · " + peerTitle(peer);
        }
        new AlertDialog.Builder(this)
                .setTitle("주변 시험 차량")
                .setItems(choices, (dialog, index) -> {
                    String id = options.get(index).optString("id");
                    if (!peers.containsKey(id)) {
                        showStatus("차량 상태가 바뀌었어요", "대상을 다시 선택해주세요.", AMBER);
                        return;
                    }
                    target = id;
                    renderTarget();
                    showStatus("받는 차량 선택됨", GUIDE, WHITE);
                })
                .setNegativeButton("닫기", null)
                .show();
    }

    private void showHistory() {
        if (busy()) return;
        if (!api.connected()) {
            connectionDialog();
            return;
        }
        api.request("/history", null, (response, code, error) -> {
            if (reportError(code, error) || !active) return;
            JSONArray messages = response.optJSONArray("messages");
            ArrayList<String> lines = new ArrayList<>();
            for (int i = 0; messages != null && i < messages.length(); i++) {
                JSONObject message = messages.optJSONObject(i);
                if (message == null) continue;
                String state = deliveryStatus(message.optString("state"));
                String elapsed = message.isNull("deliveredAt") ? "" : String.format(Locale.KOREA,
                        " · %.1f초", Math.max(0, message.optDouble("deliveredAt") - message.optDouble("acceptedAt")));
                String original = message.has("original") ? "\n음성 인식: " + message.optString("original") : "";
                boolean inbound = "수신".equals(message.optString("direction"));
                lines.add(message.optString("direction") + " · "
                        + message.optString(inbound ? "senderPlate" : "recipientPlate") + " · " + state + elapsed
                        + (inbound ? " · " + message.optString("playback") : "")
                        + "\n" + message.optString("text") + original);
            }
            AlertDialog.Builder dialog = new AlertDialog.Builder(this)
                    .setTitle("송수신 기록").setPositiveButton("닫기", null);
            if (lines.isEmpty()) dialog.setMessage("아직 송수신 기록이 없어요.");
            else dialog.setItems(lines.toArray(new String[0]), null);
            dialog.show();
        });
    }

    @Override
    public void onGesture(boolean opened, QuickMessage highlighted) {
        if (highlighted != null) {
            showStatus(highlighted.label, presets[highlighted.ordinal()], MINT);
        } else if (opened) {
            showStatus("보낼 방향 선택", "누른 상태에서 원하는 방향으로 밀어주세요.", WHITE);
        } else {
            showStatus("보낼 메시지 선택", GUIDE, WHITE);
        }
    }

    @Override
    public void onAccessibleChoose() {
        if (busy()) return;
        QuickMessage[] messages = QuickMessage.CLOCKWISE;
        String[] labels = new String[messages.length];
        for (int i = 0; i < messages.length; i++) labels[i] = presets[i];
        new AlertDialog.Builder(this)
                .setTitle("퀵 메시지 선택")
                .setItems(labels, (dialog, index) -> onChoose(messages[index]))
                .setNegativeButton("닫기", null)
                .show();
    }

    @Override
    public void onChoose(QuickMessage message) {
        if (busy()) return;
        if (!api.connected() || !peers.containsKey(target)) {
            showStatus("받는 차량을 먼저 선택해주세요", "서버 연결과 주변 차량 목록을 확인해주세요.", AMBER);
            return;
        }
        String text = presets[message.ordinal()];
        pending = new PendingMessage(text, target, SystemClock.uptimeMillis());
        trackingTap = false;
        radial.setPending(true);
        showStatus("전송 대기 중 · 두 번 탭해 취소", text, WHITE);
        time.setVisibility(View.VISIBLE);
        progress.setVisibility(View.VISIBLE);
        updateCountdown();
    }

    private void updateCountdown() {
        if (pending == null) return;
        long remaining = pending.remaining(SystemClock.uptimeMillis());
        if (remaining == 0) {
            finishPending(true);
            return;
        }
        time.setText(String.format(Locale.KOREA, "%.1f초", Math.ceil(remaining / 100.0) / 10.0));
        progress.setProgress((int) (100 * remaining / PendingMessage.DELAY_MS));
        main.postDelayed(tick, Math.min(50, remaining));
    }

    private void finishPending(boolean completed) {
        PendingMessage result = pending;
        if (result == null) return;
        pending = null;
        trackingTap = false;
        main.removeCallbacks(tick);
        radial.setPending(false);
        time.setVisibility(View.GONE);
        progress.setVisibility(View.GONE);
        if (completed) {
            String id = UUID.randomUUID().toString();
            send("/messages", RideApi.json("id", id, "recipient", result.recipient,
                    "type", "quick", "text", result.text), true);
        } else {
            showStatus("전송 취소", "메시지를 보내지 않았어요.", AMBER);
            pumpPlayback();
        }
    }

    private boolean busy() {
        return pending != null || sending || voiceActive || connecting;
    }

    private EditText field(String hint, String value, int inputType) {
        EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setInputType(inputType);
        field.setHint(hint);
        field.setText(value);
        return field;
    }

    private void connectionDialog() {
        if (busy()) return;
        if (api.connected()) {
            String tripLabel = TripService.running() ? "백그라운드 수신 종료" : "백그라운드 수신 켜기";
            new AlertDialog.Builder(this).setTitle("연결 관리").setMessage(connectivity.getText())
                    .setPositiveButton("연결 끊기", (dialog, which) -> {
                        connecting = true;
                        api.request("/logout", new JSONObject(), (response, code, error) -> disconnectLocal());
                    })
                    .setNeutralButton(tripLabel, (dialog, which) -> toggleTrip())
                    .setNegativeButton("닫기", null).show();
            return;
        }
        new AlertDialog.Builder(this).setTitle("서버 연결")
                .setItems(new String[]{"시험 차량 A/B/C 연결", "일회용 코드로 차량 등록", "등록한 기기로 연결"},
                        (dialog, index) -> {
                            if (index == 0) trialConnectionDialog();
                            else enrollmentDialog(index == 1);
                        })
                .setNegativeButton("닫기", null).show();
    }

    private void trialConnectionDialog() {
        LinearLayout content = column();
        content.setPadding(dp(20), dp(8), dp(20), 0);
        content.addView(text("같은 Wi-Fi의 시험 서버 주소와 서버에 표시된 코드를 입력해주세요.", 14, WHITE, false));
        EditText address = field("예: http://192.168.0.10:8765", settings.getString("address", ""),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        EditText codeField = field("시험 코드 6자리", "", InputType.TYPE_CLASS_NUMBER);
        addWithTop(content, address, 8);
        addWithTop(content, codeField, 6);
        int[] profile = {settings.getInt("profile", 0)};
        TextView choose = action(VEHICLES[profile[0]], () -> {});
        choose.setOnClickListener(view -> new AlertDialog.Builder(this).setTitle("내 시험 차량")
                .setItems(VEHICLES, (dialog, index) -> {
                    profile[0] = index;
                    choose.setText(VEHICLES[index]);
                }).show());
        addWithTop(content, choose, 8);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("시험 서버 연결")
                .setView(content).setPositiveButton("연결", null).setNegativeButton("취소", null).create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String addressValue;
            try { addressValue = RideApi.address(address.getText().toString()); }
            catch (IllegalArgumentException ex) {
                address.setError("같은 Wi-Fi의 사설 IP 주소 또는 HTTPS 주소를 입력해주세요.");
                return;
            }
            String pairCode = codeField.getText().toString().trim();
            if (!pairCode.matches("[0-9]{6}")) {
                codeField.setError("코드 6자리를 입력해주세요.");
                return;
            }
            dialog.dismiss();
            connect(addressValue, pairCode, profile[0]);
        }));
        dialog.show();
    }

    private void connect(String address, String code, int profile) {
        api.configure(address);
        connecting = true;
        showStatus("서버 연결 중", VEHICLES[profile], WHITE);
        api.request("/session", RideApi.json("profile", Character.toString((char) ('A' + profile)),
                "pairCode", code, "retentionDays", settings.getInt("retention", 7)), (response, status, error) -> {
            if (connected(response, status, error)) {
                settings.edit().putString("address", address).putInt("profile", profile).apply();
            }
        });
    }

    private boolean connected(JSONObject response, int status, String error) {
        connecting = false;
        if (reportError(status, error)) return false;
        String token = response.optString("token");
        if (token.isEmpty()) {
            showStatus("연결 실패", "응답을 확인해주세요.", AMBER);
            return false;
        }
        api.authenticate(token);
        if (response.optInt("protocol") != 2) {
            api.request("/logout", new JSONObject(), (result, code, failure) -> {});
            api.reset();
            showStatus("서버 버전 확인", "현재 앱과 호환되는 차친구 서버를 실행해주세요.", AMBER);
            return false;
        }
        ownPlate = response.optString("plate");
        locationRequired = response.optBoolean("locationRequired", true);
        connectivity.setText(ownPlate);
        showStatus("서버 연결됨", locationRequired ? "위치 확인 후 주변 차량을 선택해주세요."
                : "GPS 없는 연결 시험. 다른 단말에서 별도 차량을 연결해주세요.", MINT);
        renderTarget();
        if (locationRequired && active) requestLocation();
        startHeartbeat();
        return true;
    }

    private void enrollmentDialog(boolean activate) {
        LinearLayout fields = column();
        fields.setPadding(dp(20), dp(8), dp(20), 0);
        EditText address = field("https:// 서버 주소", settings.getString("registered_server", ""),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        EditText code = field("운영자가 발급한 16자리 코드", "",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        fields.addView(address);
        if (activate) addWithTop(fields, code, 8);
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(activate ? "차량 등록" : "등록 기기 연결")
                .setView(fields).setPositiveButton(activate ? "등록" : "연결", null)
                .setNegativeButton("취소", null);
        if (!activate) builder.setNeutralButton("이 기기 등록 초기화", (dialog, which) -> {
            String server;
            try { server = RideApi.address(address.getText().toString()); }
            catch (IllegalArgumentException ex) {
                showStatus("주소를 확인해주세요", "등록 서버의 HTTPS 주소가 필요해요.", AMBER);
                return;
            }
            new AlertDialog.Builder(this).setTitle("이 기기의 등록을 지울까요?")
                    .setMessage("다음 연결에 운영자의 새 등록 코드가 필요해요.")
                    .setNeutralButton("취소", null)
                    .setPositiveButton("이 기기에서 지우기", (confirm, choice) -> {
                        enrollment.forget(server);
                        showStatus("기기 등록 정보 삭제", "새 등록 코드를 받은 뒤 연결해주세요.", WHITE);
                    }).show();
        });
        AlertDialog dialog = builder.create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String server;
            try {
                server = RideApi.address(address.getText().toString());
                if (!server.startsWith("https://")) throw new IllegalArgumentException();
            } catch (IllegalArgumentException ex) {
                address.setError("신뢰하는 HTTPS 서버 주소를 입력해주세요.");
                return;
            }
            String invite = code.getText().toString().trim().toUpperCase(Locale.ROOT);
            if (activate && !invite.matches("[0-9A-F]{16}")) {
                code.setError("코드 16자리를 입력해주세요.");
                return;
            }
            String secret;
            try { secret = enrollment.get(server, activate); }
            catch (GeneralSecurityException ex) {
                address.setError("기기 등록 정보를 읽을 수 없어요. 기존 등록을 초기화한 뒤 새 코드를 사용해주세요.");
                return;
            }
            if (secret == null) {
                address.setError("이 서버에서 발급한 코드로 먼저 기기를 등록해주세요.");
                return;
            }
            dialog.dismiss();
            api.configure(server);
            connecting = true;
            showStatus("등록 서버 연결 중", "", WHITE);
            api.request(activate ? "/enroll" : "/device-session",
                    RideApi.json("deviceSecret", secret, "code", invite), (response, status, error) -> {
                        if (connected(response, status, error)) {
                            settings.edit().putString("registered_server", server)
                                    .putInt("retention", response.optInt("retentionDays", 7)).apply();
                        }
                    });
        }));
        dialog.show();
    }

    private void disconnectLocal() {
        TripService.stop();
        inbox.reset();
        api.reset();
        main.removeCallbacks(heartbeat);
        devices.stopLocation();
        cancelVoice(false);
        peers.clear();
        deliveries.clear();
        received.setVisibility(View.GONE);
        target = "";
        radial.setPending(false);
        connecting = sending = polling = locating = historyPolling = locationReady = false;
        lastServiceMessage = "";
        lastHistoryCheck = 0;
        connectivity.setText("서버 연결");
        renderTarget();
        showStatus("서버 연결 종료", "다시 연결하려면 오른쪽 위를 눌러주세요.", WHITE);
    }

    private boolean hasFineLocation() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocation() {
        if (!locationRequired || TripService.running()) return;
        if (!hasFineLocation()) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION);
            return;
        }
        locating = true;
        devices.startLocation();
    }

    private void startHeartbeat() {
        main.removeCallbacks(heartbeat);
        if (active && api.connected()) main.post(heartbeat);
    }

    private void pollPresence() {
        if (!active || !api.connected()) return;
        main.postDelayed(heartbeat, 1000);
        expireDeliveryChecks();
        if (polling) return;
        polling = true;
        boolean service = TripService.running();
        if (service && locating) {
            devices.stopLocation();
            locating = false;
        }
        if (!service && locationRequired && !locating && hasFineLocation()) requestLocation();
        JSONObject presence = service ? null : RideApi.presence(locationRequired
                ? devices.locationBody() : new JSONObject());
        api.request(service ? "/peers" : "/presence", presence, (response, code, error) -> {
            polling = false;
            if (code == 401) {
                reportError(code, error);
                return;
            }
            if (!active || error != null) {
                if (active) {
                    peers.clear();
                    locationReady = false;
                    renderTarget();
                    connectivity.setText("연결 확인 중");
                }
                return;
            }
            connectivity.setText(ownPlate);
            locationReady = response.optBoolean("locationReady");
            peers.clear();
            JSONArray list = response.optJSONArray("peers");
            for (int i = 0; list != null && i < list.length(); i++) {
                JSONObject peer = list.optJSONObject(i);
                if (peer != null) peers.put(peer.optString("id"), peer);
            }
            if (!peers.containsKey(target)) target = "";
            renderTarget();
            if (TripService.running()) {
                JSONObject last = TripService.latestMessage();
                if (last != null && !lastServiceMessage.equals(last.optString("id"))) {
                    lastServiceMessage = last.optString("id");
                    showReceived(last);
                }
            } else inbox.fetch();
            long now = SystemClock.elapsedRealtime();
            if (deliveries.hasPending() && now - lastHistoryCheck >= 1400) {
                fetchDeliveryStates();
            }
        });
    }

    private String peerTitle(JSONObject peer) {
        return peer.optString("label").replaceFirst(" · [0-9]{4}$", "")
                + (peer.isNull("meters") ? "" : " · 약 " + peer.optInt("meters") + "m");
    }

    private boolean reportError(int code, String error) {
        if (code == 401) disconnectLocal();
        if (error == null) return false;
        showStatus(code == 401 ? "다시 연결해주세요" : "요청을 처리하지 못했어요", error, AMBER);
        return true;
    }

    private void send(String path, JSONObject payload, boolean retry) {
        String id = payload.optString("id");
        deliveries.begin(id);
        sending = true;
        radial.setPending(true);
        showStatus("전송 중", path.equals("/voice") ? "음성 문구를 확인하는 중이에요." : payload.optString("text"), WHITE);
        api.request(path, payload, (response, code, error) -> {
            if (code == 0 && error != null && retry && active) {
                send(path, payload, false);
                return;
            }
            sending = false;
            radial.setPending(false);
            if (code == 0 && error != null) {
                deliveries.expect(id, SystemClock.elapsedRealtime(), false);
                showStatus("전송 결과 확인 중", "서버 연결이 돌아오면 송수신 기록에서 자동으로 확인해요.", AMBER);
                pumpPlayback();
                return;
            }
            if (reportError(code, error)) {
                pumpPlayback();
                return;
            }
            String elapsed = path.equals("/voice") && lastVoiceEnd > 0
                    ? String.format(Locale.KOREA, " · 발화 종료→접수 응답 %.1f초",
                        (SystemClock.elapsedRealtime() - lastVoiceEnd) / 1000.0) : "";
            showStatus("서버 접수 완료", response.optString("text") + elapsed, WHITE);
            deliveries.expect(id, SystemClock.elapsedRealtime(), true);
            pumpPlayback();
        });
    }

    private void fetchDeliveryStates() {
        if (historyPolling) return;
        historyPolling = true;
        lastHistoryCheck = SystemClock.elapsedRealtime();
        api.request("/history", null, (response, code, error) -> {
            historyPolling = false;
            if (code == 401) { reportError(code, error); return; }
            if (error != null || !active) return;
            expireDeliveryChecks();
            JSONArray entries = response.optJSONArray("messages");
            for (int i = 0; entries != null && i < entries.length(); i++) {
                JSONObject entry = entries.optJSONObject(i);
                if (entry == null || !"송신".equals(entry.optString("direction"))) continue;
                String id = entry.optString("id");
                String state = entry.optString("state");
                DeliveryTracker.Update update = deliveries.observe(id, state);
                if (update == DeliveryTracker.Update.NONE) continue;
                if (deliveries.isLatest(id) && !busy()) {
                    int color = update == DeliveryTracker.Update.EXPIRED ? AMBER : MINT;
                    showStatus(deliveryStatus(state), entry.optString("text"), color);
                }
                if (update == DeliveryTracker.Update.DELIVERED && !voiceActive) completionSound();
            }
        });
    }

    private void expireDeliveryChecks() {
        if (deliveries.expire(SystemClock.elapsedRealtime()) && !busy()) {
            showStatus("전송 여부를 확인하지 못했어요", "나중에 송수신 기록을 확인해주세요.", AMBER);
        }
    }

    private String deliveryStatus(String state) {
        if ("delivered".equals(state)) return "상대 앱 수신 확인";
        if ("expired".equals(state)) return "전달 만료";
        return "서버 접수 · 발송 중";
    }

    private void completionSound() {
        try {
            ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 50);
            tone.startTone(ToneGenerator.TONE_PROP_ACK, 100);
            new Handler(Looper.getMainLooper()).postDelayed(tone::release, 180);
        } catch (RuntimeException ignored) {
            // The visual confirmation remains available on devices without this audio stream.
        }
    }

    private void showReceived(JSONObject message) {
        received.setText(message.optString("senderPlate") + " · " + message.optString("text"));
        received.setVisibility(View.VISIBLE);
    }

    private void pumpPlayback() {
        inbox.pump();
        TripService.resumePlayback();
    }

    private void startVoice() {
        if (voiceActive) {
            cancelVoice(true);
            return;
        }
        if (busy()) return;
        boolean speaking = inbox.speaking() || TripService.speaking();
        if (!api.connected() || peers.isEmpty() || speaking) {
            showStatus("음성 시작 대기", speaking ? "받은 메시지 재생 후 다시 시작해주세요."
                    : "먼저 서버를 연결하고 주변 차량이 표시되는지 확인해주세요.", AMBER);
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION);
            return;
        }
        int attempt = ++voiceGeneration;
        voiceActive = true;
        TripService.reserveMicrophone(true);
        voiceButton.setText("음성 입력 취소");
        listen(attempt, "호출어 말하기", "“안녕 차친구야”라고 말해주세요.",
                "호출어를 말해 주세요.", (phrase, endedAt) -> {
            if (!VoiceInput.isWakePhrase(phrase)) {
                voiceFailure("호출어를 다시 말해주세요.");
                return;
            }
            listenForVehicle(attempt, false);
        });
    }

    private void listenForVehicle(int attempt, boolean retry) {
        listenForResults(attempt, retry ? "차량번호 다시 말하기" : "차량번호 말하기",
                retry ? "다른 차량 번호로도 들렸어요. 뒤 네 자리를 한 자리씩 다시 말해주세요."
                        : "받는 차량번호 뒤 네 자리를 한 자리씩 말해주세요.",
                retry ? "번호가 확실하지 않아요. 뒤 네 자리를 한 자리씩 다시 말해 주세요."
                        : "받는 차량 번호 뒤 네 자리를 말해 주세요.",
                VoiceInput.PLATE_RESULT_LIMIT, (results, endedAt) -> {
                    VoiceInput.PlateMatch match = VoiceInput.matchPlate(results, nearbyPlates());
                    switch (match.status) {
                        case MATCH:
                            confirmVoiceTarget(attempt, peers.get(match.recipient), match.digits);
                            break;
                        case INVALID_NUMBER:
                            voiceFailure("차량번호 뒤 네 자리를 한 자리씩 말해주세요.");
                            break;
                        case NOT_NEARBY:
                            voiceFailure("인식된 번호와 일치하는 주변 차량이 없어요.");
                            break;
                        case DUPLICATE_SUFFIX:
                            voiceFailure("같은 뒤 번호의 차량이 여러 대예요. 차량 목록에서 전체 번호를 확인해주세요.");
                            break;
                        case AMBIGUOUS_SPEECH:
                            if (retry) voiceFailure("번호가 여러 차량으로 인식됐어요. 차량 목록에서 전체 번호를 확인해주세요.");
                            else listenForVehicle(attempt, true);
                            break;
                    }
                });
    }

    private Map<String, String> nearbyPlates() {
        Map<String, String> plates = new LinkedHashMap<>();
        for (Map.Entry<String, JSONObject> peer : peers.entrySet()) {
            plates.put(peer.getKey(), peer.getValue().optString("plate"));
        }
        return plates;
    }

    private boolean verifyVoiceTarget(String recipient, String digits) {
        VoiceInput.PlateMatch match = VoiceInput.matchPlate(Collections.singletonList(digits), nearbyPlates());
        if (recipient.equals(match.recipient)) return true;
        voiceFailure("주변 차량이 바뀌었어요. 받는 차량을 다시 확인해주세요.");
        return false;
    }

    private void confirmVoiceTarget(int attempt, JSONObject peer, String digits) {
        String recipient = peer.optString("id");
        listen(attempt, "받는 차량 확인", peer.optString("plate") + " · " + peerTitle(peer)
                + "\n맞으면 “확인”이라고 말해주세요.", VoiceInput.pronouncePlate(peer.optString("plate"))
                + " 차량입니다. 맞으면 확인이라고 말해 주세요.", (answer, endedAt) -> {
            if (!answer.replaceAll("[\\s\\p{Punct}。！？]", "").equals("확인")) {
                voiceFailure("대상을 확인하지 않아 전송을 취소했어요.");
                return;
            }
            if (!verifyVoiceTarget(recipient, digits)) return;
            target = recipient;
            renderTarget();
            listen(attempt, "메시지 말하기", "할 말을 끝까지 말하면 정제 후 자동으로 전송돼요.",
                    "보낼 메시지를 말해 주세요.", (original, end) -> {
                if (!verifyVoiceTarget(recipient, digits)) return;
                long speechElapsed = end > 0 ? SystemClock.elapsedRealtime() - end : 0;
                if (speechElapsed >= 10_000) {
                    voiceFailure("음성 인식 시간이 지났어요. 다시 입력해주세요.");
                    return;
                }
                lastVoiceEnd = end;
                cancelVoice(false);
                send("/voice", RideApi.json("id", UUID.randomUUID().toString(),
                        "recipient", recipient, "digits", digits, "original", original,
                        "speechElapsedMs", speechElapsed), false);
            });
        });
    }

    interface SpeechStep {
        void accept(String text, long endedAt);
    }

    private void listen(int attempt, String heading, String prompt, String spokenPrompt, SpeechStep next) {
        listenForResults(attempt, heading, prompt, spokenPrompt, 1,
                (results, endedAt) -> next.accept(results.get(0).trim(), endedAt));
    }

    private void listenForResults(int attempt, String heading, String prompt, String spokenPrompt,
                                  int maxResults, BiConsumer<List<String>, Long> next) {
        showStatus(heading, prompt, MINT);
        devices.speakPrompt(spokenPrompt, () -> main.postDelayed(() -> {
            if (!voiceActive || attempt != voiceGeneration || !active) return;
            devices.listen(maxResults, (results, endedAt, error) -> {
                if (!voiceActive || attempt != voiceGeneration || !active) return;
                if (error != null) voiceFailure(error);
                else next.accept(results, endedAt);
            });
        }, 300));
    }

    private void voiceFailure(String message) {
        cancelVoice(false);
        showStatus("음성 전송 보류", message, AMBER);
        pumpPlayback();
    }

    private void cancelVoice(boolean notify) {
        voiceGeneration++;
        voiceActive = false;
        devices.cancelPrompt();
        devices.stopListening();
        TripService.reserveMicrophone(false);
        voiceButton.setText("음성 보내기");
        if (notify) {
            showStatus("음성 입력 취소", "메시지를 보내지 않았어요.", AMBER);
            pumpPlayback();
        }
    }

    private void settingsDialog() {
        if (busy()) return;
        new AlertDialog.Builder(this).setTitle("메시지 설정")
                .setItems(new String[]{"퀵 문구와 방향 편집", "메시지 보관 기간", "차량 차단 관리"}, (dialog, index) -> {
                    if (index == 0) choosePreset();
                    if (index == 1) retentionDialog();
                    if (index == 2) blocksDialog();
                }).setNegativeButton("닫기", null).show();
    }

    private void renderPresets() {
        String[] labels = new String[presets.length];
        for (QuickMessage direction : QuickMessage.CLOCKWISE) {
            String text = presets[direction.ordinal()];
            String label = null;
            for (QuickMessage option : QuickMessage.CLOCKWISE) {
                if (option.text.equals(text)) {
                    label = option.label;
                    break;
                }
            }
            int chars = text.codePointCount(0, text.length());
            labels[direction.ordinal()] = label != null ? label
                    : chars > 5 ? text.substring(0, text.offsetByCodePoints(0, 5)) + "…" : text;
        }
        radial.setLabels(labels);
    }

    private String directionName(int index) {
        return new String[]{"↑", "↗", "→", "↘", "↓", "↙", "←", "↖"}[index];
    }

    private String[] presetChoices() {
        String[] options = new String[presets.length];
        for (int i = 0; i < options.length; i++) options[i] = directionName(i) + "  " + presets[i];
        return options;
    }

    private void choosePreset() {
        new AlertDialog.Builder(this).setTitle("편집할 방향")
                .setItems(presetChoices(), (dialog, index) -> editPreset(index))
                .setNegativeButton("닫기", null).show();
    }

    private void editPreset(int index) {
        EditText input = field("퀵 메시지 문구", presets[index], InputType.TYPE_CLASS_TEXT);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(directionName(index) + " 퀵 문구")
                .setView(input).setPositiveButton("저장", null)
                .setNeutralButton("방향 교환", (box, which) -> new AlertDialog.Builder(this)
                        .setTitle("교환할 방향").setItems(presetChoices(), (list, other) -> {
                            String previous = presets[other];
                            presets[other] = presets[index];
                            presets[index] = previous;
                            savePresets();
                        }).setNegativeButton("취소", null).show())
                .setNegativeButton("취소", null).create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String message = input.getText().toString().trim();
            if (message.isEmpty() || message.codePointCount(0, message.length()) > 48
                    || message.matches("(?s).*[\\p{C}].*")) {
                input.setError("한 줄로 1~48자 입력해주세요.");
                return;
            }
            presets[index] = message;
            savePresets();
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void savePresets() {
        SharedPreferences.Editor editor = settings.edit();
        for (int i = 0; i < presets.length; i++) editor.putString("preset_" + i, presets[i]);
        editor.apply();
        renderPresets();
    }

    private void retentionDialog() {
        String[] choices = new String[24];
        for (int i = 0; i < choices.length; i++) choices[i] = (i + 7) + "일";
        new AlertDialog.Builder(this).setTitle("새 메시지 기록 보관 기간")
                .setSingleChoiceItems(choices, settings.getInt("retention", 7) - 7, (dialog, which) -> {
                    int days = which + 7;
                    dialog.dismiss();
                    if (!api.connected()) {
                        settings.edit().putInt("retention", days).apply();
                        return;
                    }
                    api.request("/retention", RideApi.json("days", days), (response, status, error) -> {
                        if (!reportError(status, error)) {
                            settings.edit().putInt("retention", days).apply();
                            showStatus("보관 기간 변경", "새 메시지는 " + days + "일간 보관돼요.", MINT);
                        }
                    });
                }).setNegativeButton("닫기", null).show();
    }

    private void blocksDialog() {
        if (!api.connected()) {
            connectionDialog();
            return;
        }
        api.request("/blocks", null, (response, code, error) -> {
            if (reportError(code, error) || !active) return;
            JSONArray vehicles = response.optJSONArray("vehicles");
            if (vehicles == null) return;
            String[] options = new String[vehicles.length()];
            for (int i = 0; i < options.length; i++) {
                JSONObject vehicle = vehicles.optJSONObject(i);
                options[i] = (vehicle.optBoolean("blocked") ? "해제 · " : "차단 · ") + vehicle.optString("label");
            }
            new AlertDialog.Builder(this).setTitle("차량 차단 관리").setItems(options, (dialog, index) -> {
                JSONObject vehicle = vehicles.optJSONObject(index);
                String id = vehicle.optString("id");
                boolean block = !vehicle.optBoolean("blocked");
                api.request("/blocks", RideApi.json("peer", id, "blocked", block), (result, status, failure) -> {
                    if (reportError(status, failure)) return;
                    inbox.setBlocked(id, block);
                    TripService.block(id, block);
                    if (block) {
                        peers.remove(id);
                        if (id.equals(target)) target = "";
                        renderTarget();
                    }
                    showStatus(block ? "차량 차단됨" : "차량 차단 해제됨", vehicle.optString("label"), MINT);
                });
            }).setNegativeButton("닫기", null).show();
        });
    }

    private void toggleTrip() {
        if (TripService.running()) {
            TripService.stop();
            showStatus("백그라운드 수신 종료", "앱 화면에서 수신을 계속해요.", WHITE);
            startHeartbeat();
            return;
        }
        new AlertDialog.Builder(this).setTitle("백그라운드 수신 켜기")
                .setMessage("화면을 닫아도 차량 메시지를 수신하고 소리로 읽어요. "
                        + (locationRequired ? "켜진 동안 위치를 공유해요. " : "")
                        + "알림에서 종료할 수 있고 켠 뒤 최대 2시간 유지돼요.")
                .setPositiveButton("켜기", (dialog, which) -> enableTrip())
                .setNegativeButton("취소", null).show();
    }

    private void enableTrip() {
        if (!api.connected() || !active) return;
        if (locationRequired && !hasFineLocation()) {
            requestedTrip = true;
            requestLocation();
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, TRIP_NOTIFICATION_PERMISSION);
            return;
        }
        requestedTrip = false;
        try {
            inbox.stop();
            TripService.start(this, api, locationRequired, ownPlate);
            main.postDelayed(() -> {
                if (!active || !api.connected()) return;
                if (TripService.running()) showStatus("백그라운드 수신 중", "상단 알림에서 수신을 끝낼 수 있어요.", MINT);
                else showStatus("백그라운드 수신을 켜지 못했어요", "위치와 알림 설정을 확인해주세요.", AMBER);
                startHeartbeat();
            }, 600);
        } catch (RuntimeException ex) {
            showStatus("백그라운드 수신을 켜지 못했어요", "앱이 보이는 상태에서 다시 시도해주세요.", AMBER);
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (pending == null) return super.dispatchTouchEvent(event);
        long now = SystemClock.uptimeMillis();
        if (pending.remaining(now) == 0) {
            finishPending(true);
            return true;
        }
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                trackingTap = true;
                tapDownAt = now;
                tapX = event.getX();
                tapY = event.getY();
                break;
            case MotionEvent.ACTION_MOVE:
                if (Math.hypot(event.getX() - tapX, event.getY() - tapY) > dp(24)) {
                    trackingTap = false;
                    pending.resetTaps();
                }
                break;
            case MotionEvent.ACTION_UP:
                boolean tapped = trackingTap && now - tapDownAt <= 250
                        && Math.hypot(event.getX() - tapX, event.getY() - tapY) <= dp(24);
                trackingTap = false;
                if (!tapped) pending.resetTaps();
                if (tapped && pending.cancelOnTap(now, ViewConfiguration.getDoubleTapTimeout())) {
                    finishPending(false);
                }
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
            case MotionEvent.ACTION_CANCEL:
                trackingTap = false;
                pending.resetTaps();
                break;
            default:
                break;
        }
        return true;
    }

    @Override
    protected void onStart() {
        super.onStart();
        active = true;
        if (api.connected() && locationRequired && hasFineLocation()) requestLocation();
        startHeartbeat();
    }

    @Override
    public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        if (request == LOCATION_PERMISSION) {
            boolean startTrip = requestedTrip;
            requestedTrip = false;
            if (hasFineLocation() && active) {
                if (startTrip) enableTrip();
                else requestLocation();
            } else showStatus("정확한 위치 권한 필요", "받는 차량 카드를 눌러 설정을 다시 확인해주세요.", AMBER);
        }
        if (request == MIC_PERMISSION) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED && active) startVoice();
            else showStatus("마이크 권한 필요", "음성 입력을 하려면 마이크 권한을 허용해주세요.", AMBER);
        }
        if (request == TRIP_NOTIFICATION_PERMISSION) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED && active) enableTrip();
            else showStatus("알림 권한 필요", "백그라운드 수신 중임을 알림에서 표시해요.", AMBER);
        }
    }

    @Override
    protected void onStop() {
        active = false;
        main.removeCallbacks(heartbeat);
        devices.stopLocation();
        if (api.connected() && !TripService.running()) {
            api.request("/pause", RideApi.presence(new JSONObject()), (response, code, error) -> {});
        }
        locating = false;
        cancelVoice(false);
        inbox.stop();
        radial.resetTouch();
        finishPending(false);
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        devices.close();
        api.close();
        main.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
