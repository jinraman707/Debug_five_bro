package kr.ac.capstone.chachingu;

import android.os.Handler;
import android.os.SystemClock;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;

final class RideApi implements AutoCloseable {
    private static final AtomicLong PRESENCE_SEQUENCE = new AtomicLong();
    interface Reply {
        void done(JSONObject result, int status, String error);
    }

    private final Handler main;
    private final ExecutorService jobs = Executors.newFixedThreadPool(3);
    private String base;
    private String token = "";
    private int generation;

    RideApi(Handler main) {
        this.main = main;
    }

    static String address(String raw) {
        URI uri = URI.create(raw.trim());
        String host = uri.getHost();
        String scheme = uri.getScheme();
        boolean localHttp = "http".equals(scheme) && privateHost(host);
        if (host == null || !(localHttp || "https".equals(scheme))
                || uri.getUserInfo() != null || uri.getQuery() != null || uri.getFragment() != null
                || !("/".equals(uri.getPath()) || "".equals(uri.getPath()))
                || uri.getPort() == 0 || uri.getPort() > 65535) {
            throw new IllegalArgumentException("https 주소 또는 같은 Wi-Fi의 사설 IP 주소를 입력해주세요.");
        }
        return scheme + "://" + uri.getRawAuthority();
    }

    private static boolean privateHost(String host) {
        if ("localhost".equals(host) || "[::1]".equals(host)) return true;
        if (host == null || !host.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) return false;
        String[] parts = host.split("\\.");
        for (String part : parts) if (Integer.parseInt(part) > 255 || (part.length() > 1 && part.startsWith("0"))) return false;
        int first = Integer.parseInt(parts[0]);
        int second = Integer.parseInt(parts[1]);
        return first == 10 || first == 127 || (first == 192 && second == 168)
                || (first == 172 && second >= 16 && second <= 31);
    }

    void configure(String address) {
        reset();
        base = address;
    }

    void authenticate(String token) {
        this.token = token;
    }

    String base() {
        return base;
    }

    String sessionToken() {
        return token;
    }

    static JSONObject presence(JSONObject fix) {
        try {
            fix.put("seq", PRESENCE_SEQUENCE.updateAndGet(last -> Math.max(last + 1, SystemClock.elapsedRealtimeNanos())));
            return fix;
        } catch (JSONException ex) {
            throw new IllegalArgumentException(ex);
        }
    }

    boolean connected() {
        return !token.isEmpty();
    }

    void reset() {
        generation++;
        token = "";
    }

    void request(String path, JSONObject body, Reply reply) {
        int requestGeneration = generation;
        String url = base + path;
        String credential = token;
        jobs.execute(() -> {
            HttpURLConnection connection = null;
            JSONObject result = null;
            String error = null;
            int status = 0;
            try {
                connection = (HttpURLConnection) URI.create(url).toURL().openConnection();
                connection.setInstanceFollowRedirects(false);
                connection.setConnectTimeout(2500);
                connection.setReadTimeout(path.equals("/voice") ? 10_000 : 2500);
                if (!credential.isEmpty()) connection.setRequestProperty("Authorization", "Bearer " + credential);
                if (body != null) {
                    connection.setRequestMethod("POST");
                    connection.setDoOutput(true);
                    byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
                    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    connection.setFixedLengthStreamingMode(payload.length);
                    try (OutputStream stream = connection.getOutputStream()) {
                        stream.write(payload);
                    }
                }
                status = connection.getResponseCode();
                InputStream input = status == 200 ? connection.getInputStream() : connection.getErrorStream();
                try (InputStream stream = input; ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
                    if (stream == null) throw new IOException("empty response");
                    byte[] buffer = new byte[4096];
                    int count;
                    while ((count = stream.read(buffer)) != -1) {
                        bytes.write(buffer, 0, count);
                        if (bytes.size() > 262_144) throw new IOException("oversize response");
                    }
                    result = new JSONObject(new String(bytes.toByteArray(), StandardCharsets.UTF_8));
                }
                if (status != 200) error = result.optString("error", "서버 응답을 확인해주세요.");
            } catch (Exception exception) {
                if (status == 200) status = 0;
                error = "서버 응답을 확인할 수 없어요. 주소와 연결 상태를 확인해주세요.";
            } finally {
                if (connection != null) connection.disconnect();
            }
            JSONObject response = result;
            String message = error;
            int code = status;
            main.post(() -> {
                if (generation == requestGeneration) reply.done(response, code, message);
            });
        });
    }

    static JSONObject json(Object... pairs) {
        JSONObject object = new JSONObject();
        try {
            for (int i = 0; i < pairs.length; i += 2) object.put((String) pairs[i], pairs[i + 1]);
            return object;
        } catch (JSONException ex) {
            throw new IllegalArgumentException(ex);
        }
    }

    @Override
    public void close() {
        reset();
        jobs.shutdownNow();
    }
}
