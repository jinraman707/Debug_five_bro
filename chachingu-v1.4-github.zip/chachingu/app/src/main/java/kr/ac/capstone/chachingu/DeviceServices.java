package kr.ac.capstone.chachingu;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

final class DeviceServices implements AutoCloseable {
    interface Recognition {
        void result(List<String> texts, long endedAt, String error);
    }

    interface Playback {
        void state(String id, String state);
    }

    private final Context context;
    private final Handler main;
    private final LocationManager location;
    private final TextToSpeech tts;
    private final LocationListener locationListener = this::updateLocation;
    private Location lastFix;
    private boolean tracking;
    private boolean ttsReady;
    private boolean ttsInitialized;
    private boolean closed;
    private SpeechRecognizer recognizer;
    private Runnable speechTimeout;
    private String promptId;
    private Runnable promptDone;
    private Runnable promptTimeout;

    DeviceServices(Context context, Handler main, Playback playback) {
        this.context = context;
        this.main = main;
        location = context.getSystemService(LocationManager.class);
        tts = new TextToSpeech(context, status -> main.post(() -> initializeTts(status, playback)));
    }

    private void initializeTts(int status, Playback playback) {
        if (closed) return;
        ttsInitialized = true;
        if (status != TextToSpeech.SUCCESS) return;
        int available = tts.setLanguage(Locale.KOREAN);
        ttsReady = available >= TextToSpeech.LANG_AVAILABLE;
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            public void onStart(String id) { main.post(() -> routePlayback(playback, id, "재생 중")); }
            public void onDone(String id) { main.post(() -> routePlayback(playback, id, "재생 완료")); }
            public void onError(String id) { main.post(() -> routePlayback(playback, id, "재생 실패")); }
            public void onStop(String id, boolean interrupted) {
                main.post(() -> routePlayback(playback, id, "중단"));
            }
        });
    }

    private void routePlayback(Playback playback, String id, String state) {
        if (!id.startsWith("prompt-")) {
            playback.state(id, state);
        } else if (id.equals(promptId) && !"재생 중".equals(state)) {
            finishPrompt();
        }
    }

    void speakPrompt(String text, Runnable next) {
        if (!ttsReady) {
            next.run();
            return;
        }
        promptId = "prompt-" + UUID.randomUUID();
        promptDone = next;
        promptTimeout = () -> {
            tts.stop();
            finishPrompt();
        };
        main.postDelayed(promptTimeout, 6500);
        if (!play(promptId, text)) finishPrompt();
    }

    private void finishPrompt() {
        Runnable next = promptDone;
        clearPrompt();
        if (next != null) next.run();
    }

    private void clearPrompt() {
        promptId = null;
        promptDone = null;
        if (promptTimeout != null) main.removeCallbacks(promptTimeout);
        promptTimeout = null;
    }

    void cancelPrompt() {
        if (promptId == null) return;
        clearPrompt();
        tts.stop();
    }

    boolean play(String id, String text) {
        return ttsReady && tts.speak(text, TextToSpeech.QUEUE_ADD, null, id) == TextToSpeech.SUCCESS;
    }

    String unavailablePlayback() {
        return ttsInitialized && !ttsReady ? "언어 미지원" : "재생 실패";
    }

    void stopPlayback() {
        tts.stop();
    }

    private void updateLocation(Location fix) {
        lastFix = fix;
    }

    void startLocation() {
        if (tracking || location == null ||
                context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        try {
            location.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, locationListener);
            lastFix = location.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            tracking = true;
        } catch (IllegalArgumentException | SecurityException ignored) {
            lastFix = null;
        }
    }

    void stopLocation() {
        if (tracking) location.removeUpdates(locationListener);
        tracking = false;
        lastFix = null;
    }

    JSONObject locationBody() {
        Location fix = lastFix;
        if (fix == null || !fix.hasAccuracy()) return new JSONObject();
        long age = (SystemClock.elapsedRealtimeNanos() - fix.getElapsedRealtimeNanos()) / 1_000_000;
        if (age < 0 || age >= 8000) return new JSONObject();
        return RideApi.json("lat", fix.getLatitude(), "lon", fix.getLongitude(),
                "accuracy", fix.getAccuracy(), "ageMs", age,
                "speed", fix.hasSpeed() ? fix.getSpeed() : null,
                "bearing", fix.hasBearing() ? fix.getBearing() : null);
    }

    void listen(int maxResults, Recognition callback) {
        stopListening();
        boolean local = Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context);
        if (!local && !SpeechRecognizer.isRecognitionAvailable(context)) {
            callback.result(null, 0, "기기에서 한국어 음성 인식 서비스를 확인해주세요.");
            return;
        }
        try {
            recognizer = local ? SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
                    : SpeechRecognizer.createSpeechRecognizer(context);
            SpeechRecognizer current = recognizer;
            current.setRecognitionListener(new RecognitionListener() {
                private long endedAt;

                public void onReadyForSpeech(Bundle params) {}
                public void onBeginningOfSpeech() {}
                public void onRmsChanged(float rms) {}
                public void onBufferReceived(byte[] buffer) {}
                public void onPartialResults(Bundle partial) {}
                public void onEvent(int event, Bundle params) {}
                public void onEndOfSpeech() { endedAt = SystemClock.elapsedRealtime(); }

                public void onError(int error) {
                    if (recognizer != current) return;
                    stopListening();
                    callback.result(null, endedAt, error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS
                            ? "마이크 권한이 필요해요." : "말을 인식하지 못했어요. 다시 시도해주세요.");
                }

                public void onResults(Bundle results) {
                    if (recognizer != current) return;
                    ArrayList<String> texts = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String first = texts == null || texts.isEmpty() ? null : texts.get(0);
                    stopListening();
                    if (first == null || first.trim().isEmpty()) {
                        callback.result(null, endedAt, "음성을 다시 입력해주세요.");
                    } else {
                        callback.result(texts, endedAt, null);
                    }
                }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR")
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            if (maxResults > 1) intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, maxResults);
            speechTimeout = () -> {
                if (recognizer != current) return;
                stopListening();
                callback.result(null, 0, "음성 입력 시간이 지났어요. 다시 시작해주세요.");
            };
            main.postDelayed(speechTimeout, 25_000);
            current.startListening(intent);
        } catch (RuntimeException ex) {
            stopListening();
            callback.result(null, 0, "음성 인식을 시작하지 못했어요.");
        }
    }

    void stopListening() {
        if (speechTimeout != null) main.removeCallbacks(speechTimeout);
        speechTimeout = null;
        SpeechRecognizer current = recognizer;
        recognizer = null;
        if (current != null) current.destroy();
    }

    @Override
    public void close() {
        closed = true;
        cancelPrompt();
        stopLocation();
        stopListening();
        tts.shutdown();
    }
}
