package kr.ac.capstone.chachingu;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;

import org.json.JSONObject;

public final class TripService extends Service {
    private static final String CHANNEL = "chachingu_trip";
    private static final String STOP = "kr.ac.capstone.chachingu.STOP_TRIP";
    private static final int NOTIFICATION_ID = 47;
    private static final long SESSION_LIMIT = 2 * 60 * 60 * 1000;
    private static TripService owner;
    private static boolean microphoneReserved;
    private static JSONObject latest;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable tick = this::poll;
    private RideApi api;
    private DeviceServices devices;
    private Inbox inbox;
    private PowerManager.WakeLock wakeLock;
    private boolean useGps;
    private String ownPlate;
    private boolean polling;
    private boolean stopping;
    private boolean connected = true;
    private long stopAt;
    private int received;

    static void start(Context context, RideApi api, boolean gps, String plate) {
        latest = null;
        context.startForegroundService(new Intent(context, TripService.class)
                .putExtra("base", api.base())
                .putExtra("session", api.sessionToken())
                .putExtra("plate", plate)
                .putExtra("gps", gps));
    }

    static String restore(RideApi api) {
        if (!running()) return null;
        api.configure(owner.api.base());
        api.authenticate(owner.api.sessionToken());
        return owner.ownPlate;
    }

    static boolean usesGps() {
        return running() && owner.useGps;
    }

    static boolean running() {
        return owner != null && !owner.stopping;
    }

    static void stop() {
        if (owner != null) owner.stopTrip();
    }

    static boolean speaking() {
        return running() && owner.inbox.speaking();
    }

    static void reserveMicrophone(boolean reserved) {
        microphoneReserved = reserved;
        if (!reserved) resumePlayback();
    }

    static void resumePlayback() {
        if (running()) owner.inbox.pump();
    }

    static void block(String peer, boolean blocked) {
        if (running()) owner.inbox.setBlocked(peer, blocked);
    }

    static JSONObject latestMessage() {
        return running() ? latest : null;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || STOP.equals(intent.getAction())) {
            stopTrip();
            return START_NOT_STICKY;
        }
        if (api != null) return START_NOT_STICKY;
        String base = intent.getStringExtra("base");
        String token = intent.getStringExtra("session");
        ownPlate = intent.getStringExtra("plate");
        useGps = intent.getBooleanExtra("gps", true);
        if (base == null || token == null || token.isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        NotificationManager notifications = getSystemService(NotificationManager.class);
        notifications.createNotificationChannel(new NotificationChannel(CHANNEL,
                "차친구 백그라운드 수신", NotificationManager.IMPORTANCE_LOW));
        try {
            Notification notification = notification();
            if (Build.VERSION.SDK_INT >= 29) {
                int type = useGps ? ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION : 0;
                if (Build.VERSION.SDK_INT >= 34) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_REMOTE_MESSAGING;
                startForeground(NOTIFICATION_ID, notification, type);
            } else startForeground(NOTIFICATION_ID, notification);
        } catch (RuntimeException failure) {
            stopSelf();
            return START_NOT_STICKY;
        }
        stopAt = SystemClock.elapsedRealtime() + SESSION_LIMIT;
        api = new RideApi(main);
        api.configure(base);
        api.authenticate(token);
        devices = new DeviceServices(this, main, (id, state) -> inbox.playback(id, state));
        inbox = new Inbox(api, devices, () -> !stopping && owner == this, () -> !microphoneReserved,
                this::messageReceived, this::stopTrip);
        owner = this;
        PowerManager power = getSystemService(PowerManager.class);
        if (power != null) {
            wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "chachingu:trip-receive");
            wakeLock.acquire(SESSION_LIMIT);
        }
        if (useGps) devices.startLocation();
        main.post(tick);
        return START_NOT_STICKY;
    }

    private void poll() {
        if (stopping) return;
        if (SystemClock.elapsedRealtime() >= stopAt) {
            stopTrip();
            return;
        }
        main.postDelayed(tick, 1000);
        if (polling) return;
        polling = true;
        api.request("/presence", RideApi.presence(useGps ? devices.locationBody() : new JSONObject()),
                (response, code, error) -> {
                    polling = false;
                    if (stopping) return;
                    if (code == 401) { stopTrip(); return; }
                    boolean online = error == null;
                    if (connected != online) {
                        connected = online;
                        updateNotification();
                    }
                    if (online) inbox.fetch();
                });
    }

    private void messageReceived(JSONObject message) {
        latest = message;
        received++;
        updateNotification();
    }

    private void updateNotification() {
        getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, notification());
    }

    private Notification notification() {
        int options = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        Intent home = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent open = PendingIntent.getActivity(this, 1, home, options);
        PendingIntent stop = PendingIntent.getService(this, 2,
                new Intent(this, TripService.class).setAction(STOP), options);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("차친구 백그라운드 수신")
                .setContentText(connected ? received + "건 수신 · " + (useGps ? "GPS 사용 중" : "실내 시험")
                        : "서버 연결 확인 중")
                .setSmallIcon(android.R.drawable.ic_dialog_email)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, "수신 종료", stop).build())
                .build();
    }

    private void stopTrip() {
        if (stopping) return;
        stopping = true;
        if (owner == this) {
            owner = null;
            latest = null;
        }
        main.removeCallbacks(tick);
        if (inbox != null) inbox.stop();
        if (devices != null) devices.close();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (api != null && api.connected()) {
            api.request("/pause", RideApi.presence(new JSONObject()), (response, code, error) -> api.close());
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        stopTrip();
        super.onDestroy();
    }
}
