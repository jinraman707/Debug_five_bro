package kr.ac.capstone.chachingu;

import android.os.SystemClock;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.UUID;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Shared receipt and playback logic for the visible activity and optional service. */
final class Inbox {
    private static final class Entry implements Comparable<Entry> {
        final JSONObject message;
        final long expiresAt;
        final String id;
        final String sender;

        Entry(JSONObject message) {
            this.message = message;
            id = message.optString("id");
            sender = message.optString("sender");
            expiresAt = SystemClock.elapsedRealtime() + message.optLong("remainingMs");
        }

        @Override public int compareTo(Entry other) {
            int priority = Integer.compare(other.message.optInt("priority"), message.optInt("priority"));
            return priority != 0 ? priority : Double.compare(message.optDouble("acceptedAt"),
                    other.message.optDouble("acceptedAt"));
        }
    }

    private final RideApi api;
    private final DeviceServices devices;
    private final BooleanSupplier active;
    private final BooleanSupplier audioAvailable;
    private final Consumer<JSONObject> display;
    private final Runnable sessionLost;
    private final PriorityQueue<Entry> queue = new PriorityQueue<>();
    private final HashMap<String, String> claiming = new HashMap<>();
    private final HashSet<String> blocked = new HashSet<>();
    private boolean fetching;
    private Entry playing;

    Inbox(RideApi api, DeviceServices devices, BooleanSupplier active, BooleanSupplier audioAvailable,
          Consumer<JSONObject> display, Runnable sessionLost) {
        this.api = api;
        this.devices = devices;
        this.active = active;
        this.audioAvailable = audioAvailable;
        this.display = display;
        this.sessionLost = sessionLost;
    }

    void fetch() {
        if (!api.connected() || fetching || queue.size() + claiming.size() >= 12) return;
        fetching = true;
        api.request("/inbox", null, (response, code, error) -> {
            fetching = false;
            if (code == 401) { sessionLost.run(); return; }
            if (error != null || !active.getAsBoolean()) return;
            JSONArray entries = response.optJSONArray("messages");
            for (int i = 0; entries != null && i < entries.length() && claiming.size() + queue.size() < 12; i++) {
                JSONObject message = entries.optJSONObject(i);
                if (message == null) continue;
                Entry entry = new Entry(message);
                if (entry.id.isEmpty() || claiming.containsKey(entry.id) || blocked.contains(entry.sender)) continue;
                String claim = UUID.randomUUID().toString();
                claiming.put(entry.id, claim);
                acknowledge(entry, claim, true);
            }
        });
    }

    private void acknowledge(Entry entry, String claim, boolean retry) {
        api.request("/ack", RideApi.json("id", entry.id, "claimId", claim), (response, code, error) -> {
            if (code == 401) { sessionLost.run(); return; }
            if (retry && code == 0 && active.getAsBoolean() && SystemClock.elapsedRealtime() < entry.expiresAt) {
                acknowledge(entry, claim, false);
                return;
            }
            claiming.remove(entry.id);
            if (error == null && response.optBoolean("play")) {
                if (active.getAsBoolean() && !blocked.contains(entry.sender)) {
                    display.accept(entry.message);
                    queue.add(entry);
                } else record(entry.id, "중단");
            }
            pump();
        });
    }

    void pump() {
        if (!active.getAsBoolean() || !audioAvailable.getAsBoolean() || playing != null || !claiming.isEmpty()) return;
        while (!queue.isEmpty()) {
            Entry entry = queue.remove();
            if (blocked.contains(entry.sender) || SystemClock.elapsedRealtime() >= entry.expiresAt) {
                record(entry.id, "중단");
                continue;
            }
            playing = entry;
            if (devices.play(entry.id, entry.message.optString("text"))) return;
            playing = null;
            record(entry.id, devices.unavailablePlayback());
        }
    }

    boolean speaking() {
        return playing != null;
    }

    void playback(String id, String state) {
        if (playing == null || !id.equals(playing.id)) return;
        record(id, state);
        if (!"재생 중".equals(state)) {
            playing = null;
            pump();
        }
    }

    private void record(String id, String state) {
        if (api.connected()) api.request("/playback", RideApi.json("id", id, "state", state),
                (response, code, error) -> {});
    }

    void setBlocked(String peer, boolean value) {
        if (!value) {
            blocked.remove(peer);
            return;
        }
        blocked.add(peer);
        queue.removeIf(entry -> {
            if (!peer.equals(entry.sender)) return false;
            record(entry.id, "중단");
            return true;
        });
        if (playing != null && peer.equals(playing.sender)) stopCurrent();
    }

    private void stopCurrent() {
        if (playing == null) return;
        record(playing.id, "중단");
        playing = null;
        devices.stopPlayback();
    }

    void stop() {
        stopCurrent();
        for (Entry entry : queue) record(entry.id, "중단");
        queue.clear();
    }

    void reset() {
        stop();
        claiming.clear();
        blocked.clear();
        fetching = false;
    }
}
