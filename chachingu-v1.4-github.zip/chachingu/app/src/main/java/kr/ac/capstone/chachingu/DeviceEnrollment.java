package kr.ac.capstone.chachingu;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class DeviceEnrollment {
    private static final String ALIAS = "chachingu-device-v1";
    private static final char[] HEX = "0123456789abcdef".toCharArray();
    private final SharedPreferences storage;

    DeviceEnrollment(Context context) {
        storage = context.getSharedPreferences("device_enrollment", Context.MODE_PRIVATE);
    }

    String get(String server, boolean create) throws GeneralSecurityException {
        String stored = storage.getString(server, null);
        if (stored == null && !create) return null;
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            if (stored == null) {
                byte[] bytes = new byte[32];
                new SecureRandom().nextBytes(bytes);
                char[] chars = new char[64];
                for (int i = 0; i < bytes.length; i++) {
                    chars[i * 2] = HEX[(bytes[i] & 0xff) >>> 4];
                    chars[i * 2 + 1] = HEX[bytes[i] & 15];
                }
                String secret = new String(chars);
                cipher.init(Cipher.ENCRYPT_MODE, key(true));
                cipher.updateAAD(server.getBytes(StandardCharsets.UTF_8));
                String value = encode(cipher.getIV()) + "." + encode(cipher.doFinal(secret.getBytes(StandardCharsets.UTF_8)));
                if (!storage.edit().putString(server, value).commit()) {
                    throw new GeneralSecurityException("Unable to save device registration");
                }
                return secret;
            }
            String[] parts = stored.split("\\.", -1);
            if (parts.length != 2) throw new GeneralSecurityException("Invalid encrypted credential");
            cipher.init(Cipher.DECRYPT_MODE, key(false), new GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)));
            cipher.updateAAD(server.getBytes(StandardCharsets.UTF_8));
            return new String(cipher.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)), StandardCharsets.UTF_8);
        } catch (GeneralSecurityException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new GeneralSecurityException("Device registration unavailable", ex);
        }
    }

    private SecretKey key(boolean create) throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        SecretKey existing = (SecretKey) keyStore.getKey(ALIAS, null);
        if (existing != null) return existing;
        if (!create) throw new GeneralSecurityException("Missing credential key");
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return generator.generateKey();
    }

    void forget(String address) {
        storage.edit().remove(address).apply();
    }

    private static String encode(byte[] value) {
        return Base64.encodeToString(value, Base64.NO_WRAP);
    }
}
