package kr.ac.capstone.chachingu;

import java.util.HashMap;

/** Reconciles a send response with the delivery state reported by history. */
final class DeliveryTracker {
    enum Update { NONE, ACCEPTED, DELIVERED, EXPIRED }

    private static final long CHECK_WINDOW_MS = 20_000;

    private static final class Entry {
        final long deadline;
        boolean accepted;

        Entry(long deadline, boolean accepted) {
            this.deadline = deadline;
            this.accepted = accepted;
        }
    }

    private final HashMap<String, Entry> pending = new HashMap<>();
    private String latest = "";

    void begin(String id) {
        latest = id;
    }

    void expect(String id, long now, boolean accepted) {
        pending.put(id, new Entry(now + CHECK_WINDOW_MS, accepted));
    }

    boolean expire(long now) {
        Entry entry = pending.get(latest);
        boolean unconfirmed = entry != null && !entry.accepted && now >= entry.deadline;
        pending.values().removeIf(item -> now >= item.deadline);
        return unconfirmed;
    }

    boolean hasPending() {
        return !pending.isEmpty();
    }

    boolean isLatest(String id) {
        return latest.equals(id);
    }

    Update observe(String id, String state) {
        Entry entry = pending.get(id);
        if (entry == null) return Update.NONE;
        switch (state) {
            case "accepted":
                if (entry.accepted) return Update.NONE;
                entry.accepted = true;
                return Update.ACCEPTED;
            case "delivered":
                pending.remove(id);
                return Update.DELIVERED;
            case "expired":
                pending.remove(id);
                return Update.EXPIRED;
            default:
                return Update.NONE;
        }
    }

    void clear() {
        pending.clear();
        latest = "";
    }
}
