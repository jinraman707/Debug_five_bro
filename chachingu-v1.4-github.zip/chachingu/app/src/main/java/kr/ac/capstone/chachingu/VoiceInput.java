package kr.ac.capstone.chachingu;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

final class VoiceInput {
    static final int PLATE_RESULT_LIMIT = 3;
    private static final String KOREAN = "영일이삼사오육칠팔구";

    enum PlateStatus { MATCH, INVALID_NUMBER, NOT_NEARBY, DUPLICATE_SUFFIX, AMBIGUOUS_SPEECH }

    static final class PlateMatch {
        final PlateStatus status;
        final String digits;
        final String recipient;

        PlateMatch(PlateStatus status, String digits, String recipient) {
            this.status = status;
            this.digits = digits;
            this.recipient = recipient;
        }
    }

    private VoiceInput() {}

    static boolean isWakePhrase(String text) {
        return text.replaceAll("[\\s\\p{Punct}。！？]", "").equals("안녕차친구야");
    }

    static String plateDigits(String transcript) {
        if (transcript == null) return "";
        String input = transcript.replaceAll("[\\s,.\\-]", "");
        if (input.length() != 4) return "";
        StringBuilder digits = new StringBuilder(4);
        for (char ch : input.toCharArray()) {
            int number = ch >= '0' && ch <= '9' ? ch - '0' : ch == '공' ? 0 : KOREAN.indexOf(ch);
            if (number < 0) return "";
            digits.append(number);
        }
        return digits.toString();
    }

    static PlateMatch matchPlate(List<String> results, Map<String, String> plates) {
        String digits = results.isEmpty() ? "" : plateDigits(results.get(0));
        if (digits.isEmpty()) return new PlateMatch(PlateStatus.INVALID_NUMBER, digits, null);

        Set<String> alternatives = new HashSet<>();
        for (int i = 1; i < Math.min(results.size(), PLATE_RESULT_LIMIT); i++) {
            String other = plateDigits(results.get(i));
            if (!other.isEmpty() && !digits.equals(other)) alternatives.add(other);
        }

        String recipient = null;
        boolean competingPlate = false;
        for (Map.Entry<String, String> vehicle : plates.entrySet()) {
            String plate = vehicle.getValue();
            if (plate.endsWith(digits)) {
                if (recipient != null) return new PlateMatch(PlateStatus.DUPLICATE_SUFFIX, digits, null);
                recipient = vehicle.getKey();
            } else if (plate.length() >= 4 && alternatives.contains(plate.substring(plate.length() - 4))) {
                competingPlate = true;
            }
        }
        if (recipient == null) return new PlateMatch(PlateStatus.NOT_NEARBY, digits, null);
        if (competingPlate) return new PlateMatch(PlateStatus.AMBIGUOUS_SPEECH, digits, null);
        return new PlateMatch(PlateStatus.MATCH, digits, recipient);
    }

    static String pronouncePlate(String plate) {
        StringBuilder spoken = new StringBuilder();
        for (char ch : plate.toCharArray()) {
            if (ch >= '0' && ch <= '9') spoken.append(KOREAN.charAt(ch - '0')).append(' ');
            else spoken.append(ch).append(' ');
        }
        return spoken.toString().trim();
    }
}
