param(
    [string]$SdkPath = $(if ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { "$env:USERPROFILE\AppData\Local\Android\Sdk" }),
    [string]$JdkPath = "$env:ProgramFiles\Android\Android Studio\jbr",
    [string]$OutputPath = "$PSScriptRoot\build\chachingu.apk"
)
$ErrorActionPreference = 'Stop'
$tools = Join-Path $SdkPath 'build-tools\35.0.0'
$android = Join-Path $SdkPath 'platforms\android-35\android.jar'
$java = Join-Path $JdkPath 'bin'
$root = Join-Path $PSScriptRoot 'build\standalone'
$stage = Join-Path $root ([guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path "$stage\classes", "$stage\dex" | Out-Null
$OutputPath = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputPath)
New-Item -ItemType Directory -Force -Path (Split-Path $OutputPath -Parent) | Out-Null

function Invoke-AndroidTool([string]$Program, [string[]]$Arguments) {
    & $Program @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Build tool failed: $Program ($LASTEXITCODE)" }
}

$manifest = Get-Content -LiteralPath "$PSScriptRoot\app\src\main\AndroidManifest.xml" -Raw -Encoding utf8
$manifest.Replace('<manifest ', '<manifest package="kr.ac.capstone.chachingu" ') |
    Set-Content -LiteralPath "$stage\AndroidManifest.xml" -Encoding utf8
$aapt = Join-Path $tools 'aapt2.exe'
$gradle = Get-Content -LiteralPath "$PSScriptRoot\app\build.gradle" -Raw
$versionCode = [regex]::Match($gradle, '\bversionCode\s+(\d+)').Groups[1].Value
$versionName = [regex]::Match($gradle, "\bversionName\s+'([^']+)'").Groups[1].Value
if (!$versionCode -or !$versionName) { throw 'Android version metadata is missing.' }
Invoke-AndroidTool $aapt @('link', '-I', $android, '--manifest', "$stage\AndroidManifest.xml",
    '--min-sdk-version', '26', '--target-sdk-version', '34', '--version-code', $versionCode,
    '--version-name', $versionName, '-o', "$stage\unsigned.apk")

$sources = @(Get-ChildItem -LiteralPath "$PSScriptRoot\app\src\main\java" -Recurse -Filter '*.java' |
    Select-Object -ExpandProperty FullName)
Invoke-AndroidTool "$java\javac.exe" (@('-encoding', 'UTF-8', '-source', '8', '-target', '8',
    '-Xlint:-options', '-bootclasspath', "$tools\core-lambda-stubs.jar;$android", '-d', "$stage\classes") + $sources)
Invoke-AndroidTool "$java\jar.exe" @('--create', '--file', "$stage\classes.jar", '-C', "$stage\classes", '.')
Invoke-AndroidTool "$java\java.exe" @('-cp', "$tools\lib\d8.jar", 'com.android.tools.r8.D8',
    '--lib', $android, '--min-api', '26', '--output', "$stage\dex", "$stage\classes.jar")

Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [IO.Compression.ZipFile]::Open("$stage\unsigned.apk", [IO.Compression.ZipArchiveMode]::Update)
try {
    [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, "$stage\dex\classes.dex", 'classes.dex') | Out-Null
} finally {
    $archive.Dispose()
}
Invoke-AndroidTool "$tools\zipalign.exe" @('-f', '4', "$stage\unsigned.apk", "$stage\aligned.apk")
$key = Join-Path $root 'debug.keystore'
if (!(Test-Path -LiteralPath $key)) {
    Invoke-AndroidTool "$java\keytool.exe" @('-genkeypair', '-keystore', $key, '-alias', 'androiddebugkey',
        '-storepass', 'android', '-keypass', 'android', '-keyalg', 'RSA', '-keysize', '2048',
        '-validity', '10000', '-dname', 'CN=Chachingu Local Debug')
}
Invoke-AndroidTool "$java\java.exe" @('-jar', "$tools\lib\apksigner.jar", 'sign', '--ks', $key,
    '--ks-key-alias', 'androiddebugkey', '--ks-pass', 'pass:android', '--key-pass', 'pass:android',
    '--v4-signing-enabled', 'false', '--out', $OutputPath, "$stage\aligned.apk")
Invoke-AndroidTool "$java\java.exe" @('-jar', "$tools\lib\apksigner.jar", 'verify', '--verbose', $OutputPath)
Invoke-AndroidTool $aapt @('dump', 'badging', $OutputPath)
