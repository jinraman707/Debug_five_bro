"""Operator-issued vehicle enrollment for a closed deployment."""
import hashlib
import re
import secrets
import sqlite3
import unicodedata
from contextlib import closing
from dataclasses import dataclass


class RegistryError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status, self.message = status, message


@dataclass(frozen=True)
class Vehicle:
    id: str
    plate: str
    label: str
    retention_days: int


def digest(value):
    return hashlib.sha256(value.encode("ascii")).hexdigest()


def valid_device_secret(value):
    return type(value) is str and re.fullmatch(r"[0-9a-f]{64}", value) is not None


class Registry:
    def __init__(self, db):
        self.db = db
        self.db.execute("""CREATE TABLE IF NOT EXISTS vehicles (
            id TEXT PRIMARY KEY, plate TEXT NOT NULL UNIQUE, model TEXT NOT NULL, color TEXT NOT NULL,
            retention_days INTEGER NOT NULL DEFAULT 7, enabled INTEGER NOT NULL DEFAULT 1,
            device_digest TEXT UNIQUE)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS enrollment_codes (
            code_digest TEXT PRIMARY KEY, vehicle_id TEXT NOT NULL REFERENCES vehicles(id),
            expires REAL NOT NULL, used_by TEXT)""")
        self.db.commit()

    def issue(self, plate, model, color, duration_minutes, now):
        plate = re.sub(r"\s+", "", unicodedata.normalize("NFC", plate))
        model, color = model.strip(), color.strip()
        if not re.fullmatch(r"[0-9]{2,3}[가-힣][0-9]{4}", plate):
            raise RegistryError(400, "예시와 같은 형식의 번호를 입력해주세요. 예: 12가3456")
        if any(not 1 <= len(value) <= 20 or any(unicodedata.category(c).startswith("C") for c in value)
               for value in (model, color)):
            raise RegistryError(400, "차종과 색상을 각 한 줄 20자 이내로 입력해주세요.")
        if not 1 <= duration_minutes <= 1440:
            raise RegistryError(400, "코드 유효기간은 1~1440분입니다.")
        code = secrets.token_hex(8).upper()
        with self.db:
            self.db.execute("DELETE FROM enrollment_codes WHERE expires <= ?", (now,))
            self.db.execute("""INSERT INTO vehicles(id,plate,model,color) VALUES(?,?,?,?)
                ON CONFLICT(plate) DO UPDATE SET model=excluded.model,color=excluded.color""",
                            (secrets.token_hex(12), plate, model, color))
            vehicle_id = self.db.execute("SELECT id FROM vehicles WHERE plate=?", (plate,)).fetchone()[0]
            self.db.execute("DELETE FROM enrollment_codes WHERE vehicle_id=?", (vehicle_id,))
            self.db.execute("INSERT INTO enrollment_codes VALUES(?,?,?,NULL)",
                            (digest(code), vehicle_id, now + duration_minutes * 60))
        return vehicle_id, code

    def activate(self, code, device_secret, now):
        if type(code) is not str or not re.fullmatch(r"[0-9A-F]{16}", code) or not valid_device_secret(device_secret):
            raise RegistryError(403, "등록 코드와 기기 인증 정보를 확인해주세요.")
        secret_hash = digest(device_secret)
        try:
            with self.db:
                self.db.execute("BEGIN IMMEDIATE")
                row = self.db.execute("SELECT * FROM enrollment_codes WHERE code_digest=? AND expires>?",
                                      (digest(code), now)).fetchone()
                if row is None or row["used_by"] not in (None, secret_hash):
                    raise RegistryError(403, "만료됐거나 이미 사용한 등록 코드예요.")
                if row["used_by"] is None:
                    self.db.execute("UPDATE vehicles SET device_digest=?, enabled=1 WHERE id=?",
                                    (secret_hash, row["vehicle_id"]))
                    self.db.execute("UPDATE enrollment_codes SET used_by=? WHERE code_digest=?",
                                    (secret_hash, digest(code)))
                else:
                    current = self.device_owner(device_secret)
                    if current != row["vehicle_id"]:
                        raise RegistryError(403, "등록 코드를 새로 발급받아주세요.")
                return row["vehicle_id"]
        except sqlite3.IntegrityError as exc:
            raise RegistryError(409, "이 기기는 이미 다른 차량에 등록돼 있어요.") from exc

    def device_owner(self, secret):
        if not valid_device_secret(secret):
            return None
        row = self.db.execute("SELECT id FROM vehicles WHERE device_digest=? AND enabled=1",
                              (digest(secret),)).fetchone()
        return row["id"] if row else None

    def active_device(self, vehicle, secret_hash):
        row = self.db.execute("SELECT device_digest FROM vehicles WHERE id=? AND enabled=1",
                              (vehicle,)).fetchone()
        return bool(row and row["device_digest"] and secrets.compare_digest(row["device_digest"], secret_hash))

    def vehicle(self, vehicle_id):
        row = self.db.execute("SELECT * FROM vehicles WHERE id=? AND enabled=1", (vehicle_id,)).fetchone()
        if not row:
            return None
        plate = row["plate"][:-4] + " " + row["plate"][-4:]
        return Vehicle(row["id"], plate, f'{row["color"]} {row["model"]}', row["retention_days"])

    def set_retention(self, vehicle_id, days):
        with self.db:
            self.db.execute("UPDATE vehicles SET retention_days=? WHERE id=?", (days, vehicle_id))

    def revoke(self, vehicle_id):
        with self.db:
            updated = self.db.execute("UPDATE vehicles SET enabled=0, device_digest=NULL WHERE id=?",
                                      (vehicle_id,)).rowcount
            self.db.execute("DELETE FROM enrollment_codes WHERE vehicle_id=?", (vehicle_id,))
        return updated == 1


def main():
    import argparse
    import time

    parser = argparse.ArgumentParser(description="차친구 참여 차량 등록 관리")
    parser.add_argument("--db", default="chachingu-registered.sqlite3")
    commands = parser.add_subparsers(dest="command", required=True)
    add = commands.add_parser("invite", help="운영자 확인 후 일회용 차량 등록 코드 발급")
    add.add_argument("--plate", required=True)
    add.add_argument("--model", required=True)
    add.add_argument("--color", required=True)
    add.add_argument("--minutes", type=int, default=60)
    commands.add_parser("list", help="등록 차량 상태 목록")
    remove = commands.add_parser("revoke", help="차량 기기 접근 해제")
    remove.add_argument("id")
    args = parser.parse_args()
    with closing(sqlite3.connect(args.db)) as db:
        db.row_factory = sqlite3.Row
        registry = Registry(db)
        try:
            if args.command == "invite":
                vehicle, code = registry.issue(args.plate, args.model, args.color, args.minutes, time.time())
                print(f"차량 ID {vehicle} · 등록 코드 {code} · {args.minutes}분 유효")
            elif args.command == "list":
                for row in db.execute("SELECT id,plate,model,color,enabled,device_digest FROM vehicles ORDER BY plate"):
                    state = "접근 해제" if not row["enabled"] else "등록됨" if row["device_digest"] else "기기 등록 대기"
                    print(row["id"], row["plate"], row["model"], row["color"], state)
            elif registry.revoke(args.id):
                print("차량 기기 접근을 해제했습니다.")
            else:
                parser.error("차량 ID를 찾지 못했습니다.")
        except RegistryError as exc:
            parser.error(exc.message)


if __name__ == "__main__":
    main()
