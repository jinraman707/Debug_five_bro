import json
from io import BytesIO
import socket
import threading
import unittest
import uuid
from urllib.request import Request, urlopen
from unittest.mock import patch

from server import ApiError, Store, TEMPLATES, make_server, refine_voice
from registry import RegistryError


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.now = 1000
        self.store = Store(pair_code="123456", clock=lambda: self.now)
        self.addCleanup(self.store.db.close)
        self.a, self.b, self.c = (self.connect(profile) for profile in "ABC")
        self.presence(self.a, 37.3)
        self.presence(self.b, 37.30015)
        self.presence(self.c, 37.31)

    def connect(self, profile, days=7):
        return self.store.call("POST", "/session", "", {
            "profile": profile, "pairCode": "123456", "retentionDays": days})["token"]

    def presence(self, token, lat, age=0, accuracy=10):
        return self.store.call("POST", "/presence", token, {
            "lat": lat, "lon": 126.8, "accuracy": accuracy, "ageMs": age})

    def send(self, token=None, recipient="B", text=None, item=None):
        item = item or {"id": str(uuid.uuid4()), "type": "quick",
                        "recipient": recipient, "text": text or TEMPLATES[4]}
        return self.store.call("POST", "/messages", token or self.a, item)

    def error(self, status, operation, *args):
        with self.assertRaises(ApiError) as result:
            operation(*args)
        self.assertEqual(result.exception.status, status)

    def test_location_radius_quality_and_expiry(self):
        self.assertEqual([p["id"] for p in self.presence(self.a, 37.3)["peers"]], ["B"])
        self.presence(self.b, 37.3, accuracy=100)
        self.assertEqual(self.presence(self.a, 37.3)["peers"], [])
        self.presence(self.b, 37.3, age=7000)
        self.now += 1
        self.assertEqual(self.presence(self.a, 37.3)["peers"], [])
        self.error(409, self.send)

    def test_send_ack_is_only_claimed_once_and_playback_terminal(self):
        message = self.send(text="정차해 주세요.")
        data = {"id": message["id"]}
        self.assertEqual(self.store.call("GET", "/inbox", self.a, {})["messages"], [])
        self.assertEqual(self.store.call("GET", "/inbox", self.b, {})["messages"][0]["id"], message["id"])
        self.error(403, self.store.call, "POST", "/ack", self.c, data)
        self.assertTrue(self.store.call("POST", "/ack", self.b, data)["first"])
        self.assertFalse(self.store.call("POST", "/ack", self.b, data)["first"])
        for state in ("재생 완료", "재생 중"):
            self.store.call("POST", "/playback", self.b, dict(data, state=state))
        history = self.store.call("GET", "/history", self.a, {})["messages"]
        self.assertEqual((history[0]["state"], history[0]["playback"]), ("delivered", "재생 완료"))

    def test_idempotency_rate_and_priority(self):
        item = {"id": str(uuid.uuid4()), "type": "quick", "recipient": "B", "text": "사고는 없어요."}
        self.assertEqual(self.send(item=item), self.send(item=item))
        self.error(409, self.send, self.a, "B", None, dict(item, text="감사합니다."))
        urgent = self.send(text="앞에 사고가 났어요.")
        self.send()
        self.error(429, self.send)
        inbox = self.store.call("GET", "/inbox", self.b, {})["messages"]
        self.assertEqual(inbox[0]["id"], urgent["id"])
        self.assertEqual([m["priority"] for m in inbox], [1, 0, 0])
        self.now += 60
        self.presence(self.a, 37.3)
        self.presence(self.b, 37.3)
        self.send()

    def test_block_expires_pending_and_removes_target(self):
        message = self.send()
        self.store.call("POST", "/blocks", self.b, {"peer": "A", "blocked": True})
        self.assertEqual(self.presence(self.a, 37.3)["peers"], [])
        self.error(409, self.send)
        self.assertEqual(self.store.call("GET", "/inbox", self.b, {})["messages"], [])
        self.store.call("POST", "/blocks", self.b, {"peer": "A", "blocked": False})
        self.assertEqual(self.store.call("GET", "/history", self.a, {})["messages"][0]["state"], "expired")
        self.error(410, self.store.call, "POST", "/ack", self.b, {"id": message["id"]})
        self.send()

    def test_voice_matches_target_and_original_is_private(self):
        data = {"id": str(uuid.uuid4()), "recipient": "B", "digits": "5678",
                "original": "감사합니다", "speechElapsedMs": 400}
        self.error(409, self.store.call, "POST", "/voice", self.a, dict(data, digits="1234"))
        self.error(422, self.store.call, "POST", "/voice", self.a, dict(data, original="새로운 문구예요."))
        self.now += 2
        result = self.store.call("POST", "/voice", self.a, data)
        self.assertEqual(result["text"], "감사합니다.")
        self.assertEqual(self.store.call("POST", "/voice", self.a, data), result)
        self.assertEqual(result["original"], "감사합니다")
        self.assertNotIn("original", self.store.call("GET", "/inbox", self.b, {})["messages"][0])
        bypass = {"id": str(uuid.uuid4()), "recipient": "B", "type": "voice",
                  "text": "감사합니다.", "original": "감사합니다"}
        self.error(400, self.send, self.a, "B", None, bypass)

    def test_retention_and_pause(self):
        self.store.call("POST", "/retention", self.b, {"days": 30})
        message = self.send()
        self.store.call("POST", "/pause", self.b, {})
        self.error(409, self.send)
        self.error(409, self.store.call, "POST", "/ack", self.b, {"id": message["id"]})
        self.presence(self.b, 37.3)
        self.store.call("POST", "/ack", self.b, {"id": message["id"]})
        self.now += 7 * 86400
        self.a, self.b = self.connect("A"), self.connect("B")
        self.assertEqual(self.store.call("GET", "/history", self.a, {})["messages"], [])
        self.assertEqual(len(self.store.call("GET", "/history", self.b, {})["messages"]), 1)

    def test_reordered_presence_cannot_override_latest_state(self):
        newer = {"seq": 81, "lat": 37.3, "lon": 126.8, "accuracy": 10, "ageMs": 0}
        self.store.call("POST", "/presence", self.b, newer)
        self.store.call("POST", "/pause", self.b, {"seq": 80})
        self.assertEqual(len(self.store.call("GET", "/peers", self.a, {})["peers"]), 1)
        self.store.call("POST", "/pause", self.b, {"seq": 82})
        self.store.call("POST", "/presence", self.b, newer)
        self.assertEqual(self.store.call("GET", "/peers", self.a, {})["peers"], [])
        self.store.call("POST", "/presence", self.b, dict(newer, seq=83))
        self.assertEqual(len(self.store.call("GET", "/peers", self.a, {})["peers"]), 1)

    def test_paused_sender_and_receiver_resume_in_gps_mode(self):
        pending = self.send(self.b, "A")
        self.store.call("POST", "/pause", self.a, {})
        self.assertEqual(self.store.call("GET", "/peers", self.a, {})["peers"], [])
        self.assertEqual(self.store.call("GET", "/inbox", self.a, {})["messages"], [])
        self.error(409, self.send)
        self.presence(self.a, 37.3)
        self.assertEqual(self.store.call("GET", "/inbox", self.a, {})["messages"][0]["id"], pending["id"])
        self.send()

    def test_lab_paused_sender_cannot_send_or_start_refinement(self):
        self.store.location_required = False
        voice = {"id": str(uuid.uuid4()), "recipient": "B", "digits": "5678",
                 "original": "감사합니다", "speechElapsedMs": 400}
        self.store.call("POST", "/pause", self.a, {})
        self.assertEqual(self.store.call("GET", "/peers", self.a, {})["peers"], [])
        self.error(409, self.send)
        with patch("server.refine_voice") as refine:
            self.error(409, self.store.call, "POST", "/voice", self.a, voice)
            refine.assert_not_called()
        self.store.call("POST", "/presence", self.a, {})
        self.send()
        self.assertEqual(self.store.call("POST", "/voice", self.a, voice)["id"], voice["id"])

    def test_pausing_during_lab_voice_refinement_discards_the_result(self):
        self.store.location_required = False
        voice = {"id": str(uuid.uuid4()), "recipient": "B", "digits": "5678",
                 "original": "감사합니다", "speechElapsedMs": 400}

        def refine_after_pause(*_):
            self.store.call("POST", "/pause", self.a, {})
            self.store.call("POST", "/presence", self.a, {})
            return "감사합니다."

        with patch("server.refine_voice", side_effect=refine_after_pause):
            self.error(409, self.store.call, "POST", "/voice", self.a, voice)
        self.assertEqual(self.store.call("GET", "/history", self.a, {})["messages"], [])

    def test_expired_sender_cannot_replay_while_recipient_retains_history(self):
        self.store.call("POST", "/retention", self.b, {"days": 30})
        quick = {"id": str(uuid.uuid4()), "recipient": "B", "text": TEMPLATES[4], "type": "quick"}
        voice = {"id": str(uuid.uuid4()), "recipient": "B", "digits": "5678",
                 "original": "감사합니다", "speechElapsedMs": 400}
        self.send(item=quick)
        self.store.call("POST", "/voice", self.a, voice)
        self.now += 7 * 86400
        self.store.purge_history(self.now)
        self.a, self.b = self.connect("A"), self.connect("B", 30)
        self.error(410, self.send, self.a, "B", None, quick)
        self.error(410, self.store.call, "POST", "/voice", self.a, voice)
        self.assertEqual(self.store.call("GET", "/history", self.a, {})["messages"], [])
        received = self.store.call("GET", "/history", self.b, {})["messages"]
        self.assertEqual({message["id"] for message in received}, {quick["id"], voice["id"]})

    def test_lost_ack_response_retries_same_claim_without_another_claim(self):
        sent = self.send()
        receipt = {"id": sent["id"], "claimId": str(uuid.uuid4())}
        first = self.store.call("POST", "/ack", self.b, receipt)
        self.assertTrue(first["play"])
        retry = self.store.call("POST", "/ack", self.b, receipt)
        self.assertTrue(retry["play"])
        self.assertFalse(retry["first"])
        other = self.store.call("POST", "/ack", self.b, dict(receipt, claimId=str(uuid.uuid4())))
        self.assertFalse(other["play"])
        self.store.call("POST", "/playback", self.b, {"id": sent["id"], "state": "재생 완료"})
        self.assertFalse(self.store.call("POST", "/ack", self.b, receipt)["play"])
        self.assertEqual(self.store.call("GET", "/history", self.a, {})["messages"][0]["deliveredAt"], self.now)


class RegistrationTests(unittest.TestCase):
    def setUp(self):
        self.now = 1000
        self.store = Store(clock=lambda: self.now, registered_only=True, location_required=False)
        self.addCleanup(self.store.db.close)

    def call(self, path, token="", **data):
        return self.store.call("POST", path, token, data)

    def invite(self, plate):
        return self.store.registry.issue(plate, "세단", "검정", 10, self.now)

    def test_activation_retry_restart_session_reissue_and_revoke(self):
        vehicle, code = self.invite("12가 3456")
        first = self.call("/enroll", code=code, deviceSecret="a" * 64)
        retry = self.call("/enroll", code=code, deviceSecret="a" * 64)
        self.assertNotEqual(first["token"], retry["token"])
        self.assertEqual(first["profile"], vehicle)
        with self.assertRaises(ApiError):
            self.store.auth(first["token"])
        with self.assertRaises(RegistryError):
            self.call("/enroll", code=code, deviceSecret="b" * 64)
        self.call("/retention", retry["token"], days=21)
        connected = self.call("/device-session", deviceSecret="a" * 64)
        self.assertEqual(connected["retentionDays"], 21)
        _, replacement = self.invite("12가3456")
        self.call("/enroll", code=replacement, deviceSecret="b" * 64)
        with self.assertRaises(ApiError):
            self.store.auth(connected["token"])
        self.assertTrue(self.store.registry.revoke(vehicle))
        with self.assertRaises(ApiError):
            self.call("/device-session", deviceSecret="b" * 64)

    def test_expired_code_and_one_device_per_vehicle(self):
        _, expired = self.invite("12가3456")
        self.now += 601
        with self.assertRaises(RegistryError):
            self.call("/enroll", code=expired, deviceSecret="a" * 64)
        _, active = self.invite("12가3456")
        self.call("/enroll", code=active, deviceSecret="a" * 64)
        _, another = self.invite("15나7890")
        with self.assertRaises(RegistryError) as result:
            self.call("/enroll", code=another, deviceSecret="a" * 64)
        self.assertEqual(result.exception.status, 409)
        self.assertEqual(self.call("/enroll", code=another, deviceSecret="b" * 64)["plate"], "15나 7890")

    def test_registered_clients_send_and_ambiguous_suffix_is_rejected(self):
        accounts = [self.invite(p) for p in ("123가1111", "345나5678", "567다5678")]
        a, b, _ = [self.call("/enroll", code=code, deviceSecret=digit * 64)["token"]
                   for digit, (_, code) in zip("abc", accounts)]
        body = {"id": str(uuid.uuid4()), "recipient": accounts[1][0], "digits": "5678",
                "original": "감사합니다", "speechElapsedMs": 400}
        with self.assertRaises(ApiError) as result:
            self.call("/voice", a, **body)
        self.assertEqual(result.exception.status, 409)
        result = self.call("/messages", a, id=str(uuid.uuid4()), recipient=accounts[1][0],
                           type="quick", text="감사합니다.")
        self.assertEqual(result["senderPlate"], "123가 1111")
        self.assertEqual(result["recipientPlate"], "345나 5678")
        self.assertEqual(self.store.call("GET", "/inbox", b, {})["messages"][0]["id"], result["id"])

    def test_default_trial_credentials_cannot_access_registered_mode(self):
        with self.assertRaises(ApiError):
            self.call("/session", profile="A", pairCode=self.store.pair_code)
        self.assertEqual(self.store.call("GET", "/health", "", {}), {"ok": True, "protocol": 2})


class HttpTests(unittest.TestCase):
    def test_http_request_parser_and_two_client_protocol(self):
        store = Store(pair_code="123456", location_required=False)
        self.addCleanup(store.db.close)
        server = make_server(store, port=0)
        self.addCleanup(server.server_close)

        class Wire:
            def __init__(self, incoming):
                self.incoming = incoming
                self.outgoing = bytearray()

            def settimeout(self, timeout):
                pass

            def makefile(self, mode, buffering):
                return BytesIO(self.incoming)

            def sendall(self, data):
                self.outgoing.extend(data)

        def call(path, token="", body=None):
            data = b"" if body is None else json.dumps(body).encode()
            method = "GET" if body is None else "POST"
            request = (f"{method} {path} HTTP/1.0\r\nAuthorization: Bearer {token}\r\n"
                       f"Content-Length: {len(data)}\r\n\r\n").encode()
            wire = Wire(request + data)
            server.RequestHandlerClass(wire, ("127.0.0.1", 55000), server)
            headers, _, payload = wire.outgoing.partition(b"\r\n\r\n")
            self.assertIn(b" 200 ", headers.splitlines()[0], payload)
            return json.loads(payload)

        a, b = (call("/session", body={"profile": profile, "pairCode": "123456"})["token"]
                for profile in "AB")
        call("/presence", a, {})
        message = call("/messages", a, {"id": str(uuid.uuid4()), "recipient": "B", "type": "quick",
                                        "text": "감사합니다."})
        self.assertEqual(call("/inbox", b)["messages"][0]["id"], message["id"])
        self.assertTrue(call("/ack", b, {"id": message["id"]})["first"])
        self.assertEqual(call("/history", a)["messages"][0]["state"], "delivered")

    def test_two_clients_over_http(self):
        store = Store(pair_code="123456", location_required=False)
        self.addCleanup(store.db.close)
        try:
            server = make_server(store, port=0)
        except OSError as exc:
            self.skipTest(f"localhost bind is unavailable ({exc})")
        self.addCleanup(server.server_close)
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        self.addCleanup(server.shutdown)
        base = "http://127.0.0.1:" + str(server.server_port)
        try:
            with socket.create_connection(server.server_address, timeout=1):
                pass
        except OSError as exc:
            self.skipTest(f"localhost connection is unavailable ({exc})")

        def call(path, token="", body=None):
            headers = {"Authorization": "Bearer " + token}
            data = None
            if body is not None:
                data = json.dumps(body).encode()
                headers["Content-Type"] = "application/json"
            with urlopen(Request(base + path, data=data, headers=headers), timeout=2) as response:
                return json.load(response)

        a, b = (call("/session", body={"profile": profile, "pairCode": "123456"})["token"]
                for profile in "AB")
        self.assertEqual(call("/presence", a, {})["peers"][0]["id"], "B")
        message = call("/messages", a, {"id": str(uuid.uuid4()), "recipient": "B", "type": "quick",
                                        "text": "감사합니다."})
        self.assertEqual(call("/inbox", b)["messages"][0]["id"], message["id"])
        self.assertTrue(call("/ack", b, {"id": message["id"]})["first"])
        self.assertEqual(call("/history", a)["messages"][0]["state"], "delivered")


class RefineTests(unittest.TestCase):
    def test_provider_output_is_validated(self):
        original = "뒤에서 2대가 따라오고 있으니 조심해주세요."

        def provider(text):
            output = {"status": "completed", "output": [
                {"type": "message", "content": [{"type": "output_text", "text": text}]}]}
            return BytesIO(json.dumps(output).encode())

        with patch("server.urlopen", return_value=provider("뒤차 2대에 주의해주세요.")) as call:
            self.assertEqual(refine_voice(original, "test-key", "test-model"), "뒤차 2대에 주의해주세요.")
            sent = json.loads(call.call_args.args[0].data)
            self.assertEqual(sent["input"], original)
            self.assertFalse(sent["store"])
        for text in ("뒤차 3대에 주의해주세요.", "REJECT", "씨발 뒤차 2대", "가" * 21):
            with self.subTest(text=text), patch("server.urlopen", return_value=provider(text)):
                with self.assertRaises(ApiError) as error:
                    refine_voice(original, "test-key", "test-model")
                self.assertEqual(error.exception.status, 422)


if __name__ == "__main__":
    unittest.main()
